// Idempotent seed: safe to run more than once. Existing users keep their passwords and
// existing roles keep any permission changes made in Settings.
import { PrismaClient, type ClientStatus, type StatusCategory } from "@prisma/client";
import bcrypt from "bcryptjs";
import { randomBytes } from "crypto";
import { DEFAULT_ROLES, PERMISSIONS, ROLE_KEYS } from "../src/lib/permissions";

const prisma = new PrismaClient();
const domain = process.env.SEED_EMAIL_DOMAIN || "wedomarketing.io";
const printed: { name: string; email: string; password: string }[] = [];

function randomPassword() {
  return randomBytes(12).toString("base64url"); // ~16 chars
}

const STATUSES: { key: string; name: string; color: string; category: StatusCategory; isDefault?: boolean }[] = [
  { key: "BACKLOG", name: "Backlog", color: "#94A3B8", category: "OPEN" },
  { key: "PENDING", name: "Pending", color: "#F59E0B", category: "OPEN", isDefault: true },
  { key: "IN_PROGRESS", name: "In Progress", color: "#3B82F6", category: "OPEN" },
  { key: "UNDER_REVIEW", name: "Under Review", color: "#8B5CF6", category: "REVIEW" },
  { key: "REVISION_REQUIRED", name: "Revision Required", color: "#EF4444", category: "REVISION" },
  { key: "COMPLETED", name: "Completed", color: "#22C55E", category: "DONE" },
  { key: "ON_HOLD", name: "On Hold", color: "#64748B", category: "OPEN" },
];

const PRIORITIES = [
  { key: "URGENT", name: "Urgent", color: "#DC2626" },
  { key: "HIGH", name: "High", color: "#F97316" },
  { key: "MEDIUM", name: "Medium", color: "#3B82F6", isDefault: true },
  { key: "LOW", name: "Low", color: "#94A3B8" },
];

const DEPARTMENTS = [
  { name: "SEO & GEO", color: "#10B981" },
  { name: "Performance Marketing", color: "#F97316" },
  { name: "Creative Production", color: "#EC4899" },
  { name: "Content & Social Media", color: "#8B5CF6" },
  { name: "Web Development", color: "#0EA5E9" },
];

// The Technical SEO Specialist's name was not provided — add them from the Team page.
const TEAM = [
  { name: "Neha", title: "SEO Specialist", departments: ["SEO & GEO"] },
  { name: "Bajal", title: "Performance Marketer", departments: ["Performance Marketing"] },
  { name: "Dhiraj", title: "AI Video Specialist", departments: ["Creative Production", "Web Development"] },
  { name: "Nikesh", title: "AI Creative Specialist", departments: ["Creative Production"] },
  { name: "Bhumik", title: "Graphic Designer", departments: ["Creative Production"] },
  { name: "Utkarsh", title: "Web Developer", departments: ["Web Development"] },
];

const CLIENTS: { name: string; status: ClientStatus; website?: string }[] = [
  ...[
    "BarrierBreak", "Integritas", "AB Magazine", "CBS Online", "Jumbo King", "Blue Divine",
    "Garden Oasis RV", "Gold Water", "Esquire RV Park", "Blink & Wink", "Q Nails & Spa Sandy Springs",
    "Stitchgift", "Climaster HVAC", "Hariomatta", "Dev Tattva", "Plot.AI",
  ].map((name) => ({ name, status: "ACTIVE" as const })),
  { name: "SupaLoan", status: "ON_HOLD" },
  { name: "Webbrella", status: "ON_HOLD" },
  { name: "Winso", status: "UPCOMING", website: "https://winso.com" },
  { name: "GolfBuyIndia", status: "UPCOMING" },
];

async function upsertUser(opts: {
  name: string; email: string; title?: string; roleId: string; password?: string; departmentIds?: string[]; allowReset?: boolean;
}) {
  const email = opts.email.toLowerCase();
  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) {
    // One-time recovery: SEED_RESET_FOUNDER_PASSWORDS=true resets founder logins to the env passwords.
    const p = opts.password;
    const strong = !!p && p.length >= 10 && /[A-Za-z]/.test(p) && /[0-9]/.test(p);
    if (opts.allowReset && process.env.SEED_RESET_FOUNDER_PASSWORDS === "true") {
      if (!strong) {
        console.warn(`  ! Not resetting ${email}: its SEED_*_PASSWORD is missing or too weak (needs 10+ chars, a letter and a number).`);
      } else {
        await prisma.user.update({
          where: { id: existing.id },
          data: { passwordHash: await bcrypt.hash(p!, 12), mustChangePassword: false, isActive: true, sessionVersion: { increment: 1 } },
        });
        await prisma.loginAttempt.deleteMany({ where: { email } });
        console.log(`  • ${opts.name} <${email}> password RESET to the value in env. Remove SEED_RESET_FOUNDER_PASSWORDS now.`);
        return existing;
      }
    }
    console.log(`  • ${opts.name} <${email}> already exists — password unchanged`);
    return existing;
  }
  const envOk = !!opts.password && opts.password.length >= 10 && /[A-Za-z]/.test(opts.password) && /[0-9]/.test(opts.password);
  if (opts.password && !envOk) {
    console.warn(`  ! Password given for ${email} is too weak (needs 10+ chars, a letter and a number) — using a random one instead.`);
  }
  const fromEnv = envOk;
  const password = envOk ? opts.password! : randomPassword();
  const user = await prisma.user.create({
    data: {
      name: opts.name,
      email,
      title: opts.title,
      roleId: opts.roleId,
      passwordHash: await bcrypt.hash(password, 12),
      mustChangePassword: !fromEnv,
      departments: { create: (opts.departmentIds ?? []).map((departmentId) => ({ departmentId })) },
    },
  });
  if (!fromEnv) printed.push({ name: opts.name, email, password });
  else console.log(`  • ${opts.name} <${email}> created with password from env`);
  return user;
}

async function main() {
  console.log("Seeding permissions & roles…");
  for (const [key, p] of Object.entries(PERMISSIONS)) {
    await prisma.permission.upsert({ where: { key }, update: { label: p.label, group: p.group }, create: { key, ...p } });
  }
  const perms = await prisma.permission.findMany();
  const permId = new Map(perms.map((p) => [p.key, p.id]));
  const roles: Record<string, string> = {};
  for (const key of ROLE_KEYS) {
    const def = DEFAULT_ROLES[key];
    const existing = await prisma.role.findUnique({ where: { key } });
    const role = existing
      ? await prisma.role.update({ where: { key }, data: { rank: def.rank } })
      : await prisma.role.create({
          data: {
            key, name: def.name, rank: def.rank, description: def.description,
            permissions: { create: def.permissions.map((k) => ({ permissionId: permId.get(k)! })) },
          },
        });
    // Super Admin always keeps every permission (prevents locking yourself out).
    if (key === "SUPER_ADMIN") {
      await prisma.rolePermission.createMany({
        data: perms.map((p) => ({ roleId: role.id, permissionId: p.id })),
        skipDuplicates: true,
      });
    }
    roles[key] = role.id;
  }

  console.log("Seeding statuses, priorities, departments, clients…");
  for (const [order, s] of STATUSES.entries()) {
    await prisma.taskStatus.upsert({ where: { key: s.key }, update: {}, create: { ...s, order, isDefault: !!s.isDefault } });
  }
  for (const [order, p] of PRIORITIES.entries()) {
    await prisma.priority.upsert({ where: { key: p.key }, update: {}, create: { ...p, order, isDefault: !!p.isDefault } });
  }
  const depts: Record<string, string> = {};
  for (const d of DEPARTMENTS) {
    const dep = await prisma.department.upsert({ where: { name: d.name }, update: {}, create: d });
    depts[d.name] = dep.id;
  }
  for (const c of CLIENTS) {
    await prisma.client.upsert({ where: { name: c.name }, update: {}, create: { ...c, services: [] } });
  }

  console.log("Seeding users…");
  await upsertUser({
    name: "Sandeep", title: "Founder", roleId: roles.SUPER_ADMIN,
    email: process.env.SEED_SUPER_ADMIN_EMAIL || `sandeep@${domain}`,
    password: process.env.SEED_SUPER_ADMIN_PASSWORD, allowReset: true,
  });
  await upsertUser({
    name: "Pradeep", title: "Co-founder", roleId: roles.ADMIN,
    email: process.env.SEED_ADMIN_EMAIL || `pradeep@${domain}`,
    password: process.env.SEED_ADMIN_PASSWORD, allowReset: true,
  });
  for (const m of TEAM) {
    await upsertUser({
      name: m.name, title: m.title, roleId: roles.MEMBER,
      email: `${m.name.toLowerCase()}@${domain}`,
      departmentIds: m.departments.map((d) => depts[d]),
    });
  }

  if (printed.length) {
    console.log("\n================  NEW LOGINS — SHOWN ONCE, SAVE THEM NOW  ================");
    for (const p of printed) console.log(`  ${p.name.padEnd(10)} ${p.email.padEnd(34)} ${p.password}`);
    console.log("  These users will be asked to choose a new password at first sign-in.");
    console.log("==========================================================================\n");
  }
  console.log("Seed complete.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
