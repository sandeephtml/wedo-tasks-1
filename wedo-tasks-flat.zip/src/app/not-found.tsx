import Link from "next/link";

export default function NotFound() {
  return (
    <main className="flex min-h-[60vh] flex-col items-center justify-center p-6 text-center">
      <p className="font-display text-5xl font-bold text-brand">404</p>
      <h1 className="mt-2 font-display text-lg font-semibold">Not found</h1>
      <p className="mt-1 text-sm text-ink-muted">This page doesn&apos;t exist, or you don&apos;t have access to it.</p>
      <Link href="/" className="btn-primary mt-5">Go home</Link>
    </main>
  );
}
