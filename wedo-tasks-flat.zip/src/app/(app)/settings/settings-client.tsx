"use client";

import { Fragment, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { ArrowDown, ArrowUp, Loader2, Lock, Pencil, Plus, Star, Trash2 } from "lucide-react";
import { ColorBadge } from "@/components/ui/bits";
import { Modal } from "@/components/ui/modal";
import { useToast } from "@/components/ui/toast";
import { deletePriority, deleteStatus, reorder, savePriority, saveStatus, setDefaultPriority, setDefaultStatus, setRolePermissions } from "@/app/actions/settings";

type Item = { id: string; name: string; color: string; category?: string; isDefault: boolean; uses: number };
const CATEGORY_LABEL: Record<string, string> = { OPEN: "Working", REVIEW: "Waiting for review", REVISION: "Sent back for revision", DONE: "Completed (approvers only)" };

export function ConfigList({ kind, items }: { kind: "status" | "priority"; items: Item[] }) {
  const toast = useToast();
  const router = useRouter();
  const [pending, start] = useTransition();
  const [edit, setEdit] = useState<Item | "new" | null>(null);
  const [form, setForm] = useState({ name: "", color: "#3B82F6", category: "OPEN" });
  const [error, setError] = useState<string | null>(null);
  const act = (fn: () => Promise<{ ok: boolean; error?: string }>, msg?: string) => start(async () => {
    const r = await fn(); if (!r.ok) toast.error(r.error!); else { if (msg) toast.success(msg); router.refresh(); }
  });
  const open = (i: Item | "new") => { setError(null); setForm(i === "new" ? { name: "", color: "#3B82F6", category: "OPEN" } : { name: i.name, color: i.color, category: i.category ?? "OPEN" }); setEdit(i); };

  return (
    <div className="card">
      <div className="flex items-center justify-between border-b border-line px-4 py-3">
        <p className="text-sm text-ink-muted">{kind === "status" ? "Order here is the column order on the board. The category controls the review workflow." : "Order here is the grouping order in list view (top = most urgent)."}</p>
        <button className="btn-primary btn-sm" onClick={() => open("new")}><Plus className="h-3.5 w-3.5" /> Add</button>
      </div>
      <ul className="divide-y divide-line">
        {items.map((i, idx) => (
          <li key={i.id} className="flex flex-wrap items-center gap-3 px-4 py-3">
            <div className="flex flex-col">
              <button aria-label="Move up" disabled={idx === 0 || pending} className="text-ink-faint hover:text-ink disabled:opacity-30" onClick={() => act(() => reorder(kind, i.id, -1))}><ArrowUp className="h-3.5 w-3.5" /></button>
              <button aria-label="Move down" disabled={idx === items.length - 1 || pending} className="text-ink-faint hover:text-ink disabled:opacity-30" onClick={() => act(() => reorder(kind, i.id, 1))}><ArrowDown className="h-3.5 w-3.5" /></button>
            </div>
            <ColorBadge color={i.color}>{i.name}</ColorBadge>
            {i.category && <span className="text-xs text-ink-muted">{CATEGORY_LABEL[i.category]}</span>}
            {i.isDefault && <span className="badge bg-brand-soft text-brand"><Star className="h-3 w-3" /> Default</span>}
            <span className="ml-auto text-xs text-ink-faint">{i.uses} task{i.uses === 1 ? "" : "s"}</span>
            <div className="flex gap-1">
              {!i.isDefault && (kind === "priority" || i.category === "OPEN") && (
                <button className="btn-ghost btn-sm" title="Make default" aria-label={`Make ${i.name} default`} onClick={() => act(() => (kind === "status" ? setDefaultStatus(i.id) : setDefaultPriority(i.id)), "Default updated")}><Star className="h-3.5 w-3.5" /></button>
              )}
              <button className="btn-ghost btn-sm" aria-label={`Edit ${i.name}`} onClick={() => open(i)}><Pencil className="h-3.5 w-3.5" /></button>
              <button className="btn-ghost btn-sm hover:text-danger" aria-label={`Delete ${i.name}`} onClick={() => act(() => (kind === "status" ? deleteStatus(i.id) : deletePriority(i.id)), "Deleted")}><Trash2 className="h-3.5 w-3.5" /></button>
            </div>
          </li>
        ))}
      </ul>
      <Modal open={!!edit} onClose={() => setEdit(null)} title={`${edit === "new" ? "Add" : "Edit"} ${kind}`} size="sm"
        footer={<><button className="btn-secondary" onClick={() => setEdit(null)}>Cancel</button><button className="btn-primary" disabled={pending || !form.name.trim()} onClick={() => start(async () => {
          const id = edit === "new" || !edit ? null : edit.id;
          const r = kind === "status" ? await saveStatus(id, form as { name: string; color: string; category: "OPEN" }) : await savePriority(id, form);
          if (!r.ok) return setError(r.error);
          toast.success("Saved"); setEdit(null); router.refresh();
        })}>{pending && <Loader2 className="h-4 w-4 animate-spin" />} Save</button></>}>
        <div className="space-y-4">
          <div><label className="label" htmlFor="cfg-name">Name</label><input id="cfg-name" className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
          <div><label className="label" htmlFor="cfg-color">Colour</label><div className="flex gap-2"><input id="cfg-color" type="color" className="h-10 w-14 cursor-pointer rounded-lg border border-line" value={form.color} onChange={(e) => setForm({ ...form, color: e.target.value.toUpperCase() })} /><input aria-label="Hex colour" className="input font-mono" value={form.color} onChange={(e) => setForm({ ...form, color: e.target.value })} /></div></div>
          {kind === "status" && (
            <div><label className="label" htmlFor="cfg-cat">Workflow category</label>
              <select id="cfg-cat" className="input" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
                {Object.entries(CATEGORY_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
              </select></div>
          )}
          {error && <p role="alert" className="rounded-lg bg-danger-soft px-3 py-2 text-sm text-danger">{error}</p>}
        </div>
      </Modal>
    </div>
  );
}

type Role = { id: string; key: string; name: string; description: string | null; users: number; keys: string[]; editable: boolean };
type Perm = { key: string; label: string; group: string };

export function RolesMatrix({ roles, permissions }: { roles: Role[]; permissions: Perm[] }) {
  const toast = useToast();
  const router = useRouter();
  const [pending, start] = useTransition();
  const [state, setState] = useState<Record<string, string[]>>(Object.fromEntries(roles.map((r) => [r.id, r.keys])));
  const dirty = roles.filter((r) => [...state[r.id]!].sort().join() !== [...r.keys].sort().join());
  const groups = [...new Set(permissions.map((p) => p.group))];
  const toggle = (roleId: string, key: string) => setState((s) => ({ ...s, [roleId]: s[roleId]!.includes(key) ? s[roleId]!.filter((k) => k !== key) : [...s[roleId]!, key] }));

  return (
    <div className="card overflow-hidden">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line px-4 py-3">
        <p className="text-sm text-ink-muted">Changes apply on each person&apos;s next page load. Super Admin always keeps every permission.</p>
        <button className="btn-primary btn-sm" disabled={!dirty.length || pending} onClick={() => start(async () => {
          for (const r of dirty) {
            const res = await setRolePermissions(r.id, state[r.id]!);
            if (!res.ok) { toast.error(`${r.name}: ${res.error}`); return; }
          }
          toast.success("Permissions saved"); router.refresh();
        })}>{pending && <Loader2 className="h-3.5 w-3.5 animate-spin" />} Save changes{dirty.length ? ` (${dirty.length})` : ""}</button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[720px]">
          <thead className="bg-page/60">
            <tr>
              <th className="table-th">Permission</th>
              {roles.map((r) => <th key={r.id} className="table-th text-center normal-case tracking-normal"><span className="block text-xs font-semibold text-ink">{r.name}</span><span className="text-[11px] font-normal">{r.users} user{r.users === 1 ? "" : "s"}</span></th>)}
            </tr>
          </thead>
          <tbody>
            {groups.map((g) => (
              <Fragment key={g}>
                <tr className="bg-page/40"><td colSpan={roles.length + 1} className="px-4 py-1.5 text-[11px] font-semibold uppercase tracking-wide text-ink-faint">{g}</td></tr>
                {permissions.filter((p) => p.group === g).map((p) => (
                  <tr key={p.key} className="border-t border-line">
                    <td className="table-td"><span className="block">{p.label}</span><code className="text-[11px] text-ink-faint">{p.key}</code></td>
                    {roles.map((r) => (
                      <td key={r.id} className="table-td text-center">
                        {r.editable ? (
                          <input type="checkbox" aria-label={`${r.name}: ${p.label}`} className="h-4 w-4 cursor-pointer accent-[rgb(var(--brand))]" checked={state[r.id]!.includes(p.key)} onChange={() => toggle(r.id, p.key)} />
                        ) : (
                          <span title="Locked" className="inline-flex items-center gap-1 text-xs text-ink-faint">{state[r.id]!.includes(p.key) ? "✓" : "—"}<Lock className="h-3 w-3" /></span>
                        )}
                      </td>
                    ))}
                  </tr>
                ))}
              </Fragment>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
