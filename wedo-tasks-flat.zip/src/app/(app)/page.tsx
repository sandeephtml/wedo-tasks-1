import { redirect } from "next/navigation";
import { can, requireUser } from "@/lib/auth";

export default async function Home() {
  const user = await requireUser();
  redirect(can(user, "dashboard.view") ? "/dashboard" : "/my-tasks");
}
