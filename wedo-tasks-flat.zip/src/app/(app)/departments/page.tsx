import type { Metadata } from "next";
import { prisma } from "@/lib/db";
import { can, requireUser } from "@/lib/auth";
import { visibleTasksWhere } from "@/lib/task-access";
import { todayDate } from "@/lib/dates";
import { DepartmentsGrid } from "./departments-grid";

export const metadata: Metadata = { title: "Departments" };

export default async function DepartmentsPage() {
  const user = await requireUser();
  const today = todayDate();
  const [departments, tasks] = await Promise.all([
    prisma.department.findMany({
      orderBy: { name: "asc" },
      include: { members: { where: { user: { isActive: true } }, include: { user: { select: { name: true, title: true } } } } },
    }),
    prisma.task.findMany({ where: visibleTasksWhere(user), select: { departmentId: true, dueDate: true, status: { select: { category: true } } } }),
  ]);
  const data = departments.map((d) => {
    const t = tasks.filter((x) => x.departmentId === d.id);
    const done = t.filter((x) => x.status.category === "DONE").length;
    return {
      id: d.id, name: d.name, color: d.color, description: d.description ?? "",
      members: d.members.map((m) => ({ name: m.user.name, title: m.user.title })),
      total: t.length, done, open: t.length - done,
      overdue: t.filter((x) => x.status.category !== "DONE" && x.dueDate && x.dueDate < today).length,
    };
  });
  return <DepartmentsGrid departments={data} canManage={can(user, "department.manage")} />;
}
