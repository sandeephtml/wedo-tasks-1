"use client";

import Link from "next/link";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Loader2, Pencil, Plus, Trash2 } from "lucide-react";
import { Avatar, PageHeader } from "@/components/ui/bits";
import { Modal } from "@/components/ui/modal";
import { useToast } from "@/components/ui/toast";
import { deleteDepartment, saveDepartment } from "@/app/actions/departments";

type D = { id: string; name: string; color: string; description: string; members: { name: string; title: string | null }[]; total: number; done: number; open: number; overdue: number };

export function DepartmentsGrid({ departments, canManage }: { departments: D[]; canManage: boolean }) {
  const [edit, setEdit] = useState<D | "new" | null>(null);
  const [del, setDel] = useState<D | null>(null);
  const [form, setForm] = useState({ name: "", color: "#6366F1", description: "" });
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();
  const toast = useToast();
  const router = useRouter();
  const open = (d: D | "new") => { setError(null); setForm(d === "new" ? { name: "", color: "#6366F1", description: "" } : { name: d.name, color: d.color, description: d.description }); setEdit(d); };

  return (
    <>
      <PageHeader title="Departments" subtitle={`${departments.length} departments`} actions={canManage ? <button className="btn-primary" onClick={() => open("new")}><Plus className="h-4 w-4" /> Add department</button> : null} />
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
        {departments.map((d) => {
          const pct = d.total ? Math.round((d.done / d.total) * 100) : 0;
          return (
            <div key={d.id} className="card flex flex-col p-5">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2"><span className="h-3 w-3 rounded-full" style={{ background: d.color }} /><h2 className="font-display font-semibold">{d.name}</h2></div>
                {canManage && (
                  <div className="flex gap-1">
                    <button aria-label={`Edit ${d.name}`} className="btn-ghost px-1.5 py-1" onClick={() => open(d)}><Pencil className="h-3.5 w-3.5" /></button>
                    <button aria-label={`Delete ${d.name}`} className="btn-ghost px-1.5 py-1 hover:text-danger" onClick={() => setDel(d)}><Trash2 className="h-3.5 w-3.5" /></button>
                  </div>
                )}
              </div>
              {d.description && <p className="mt-1 text-sm text-ink-muted">{d.description}</p>}
              <div className="mt-4">
                <div className="mb-1 flex justify-between text-xs"><span className="text-ink-muted">Completion</span><span className="font-semibold">{pct}%</span></div>
                <div className="h-2 overflow-hidden rounded-full bg-page"><div className="h-full rounded-full" style={{ width: `${pct}%`, background: d.color }} /></div>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                <div className="rounded-lg bg-page py-2"><p className="text-lg font-semibold">{d.open}</p><p className="text-[11px] text-ink-muted">Open</p></div>
                <div className="rounded-lg bg-page py-2"><p className="text-lg font-semibold text-success">{d.done}</p><p className="text-[11px] text-ink-muted">Done</p></div>
                <div className="rounded-lg bg-page py-2"><p className={`text-lg font-semibold ${d.overdue ? "text-danger" : ""}`}>{d.overdue}</p><p className="text-[11px] text-ink-muted">Overdue</p></div>
              </div>
              <div className="mt-4 flex-1">
                <p className="mb-2 text-xs font-medium text-ink-muted">Members</p>
                {d.members.length ? (
                  <ul className="space-y-1.5">{d.members.map((m) => <li key={m.name} className="flex items-center gap-2 text-sm"><Avatar name={m.name} size={24} />{m.name}{m.title && <span className="truncate text-xs text-ink-faint">· {m.title}</span>}</li>)}</ul>
                ) : <p className="text-sm text-ink-faint">No one assigned yet.</p>}
              </div>
              <Link href={`/tasks?department=${d.id}`} className="btn-secondary btn-sm mt-4">View tasks</Link>
            </div>
          );
        })}
      </div>

      <Modal open={!!edit} onClose={() => setEdit(null)} title={edit === "new" ? "Add department" : "Edit department"} size="sm"
        footer={<><button className="btn-secondary" onClick={() => setEdit(null)}>Cancel</button><button className="btn-primary" disabled={pending || !form.name.trim()} onClick={() => start(async () => {
          const r = await saveDepartment(edit === "new" || !edit ? null : edit.id, form);
          if (!r.ok) return setError(r.error);
          toast.success("Department saved"); setEdit(null); router.refresh();
        })}>{pending && <Loader2 className="h-4 w-4 animate-spin" />} Save</button></>}>
        <div className="space-y-4">
          <div><label className="label" htmlFor="d-name">Name</label><input id="d-name" className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
          <div><label className="label" htmlFor="d-color">Colour</label><div className="flex gap-2"><input id="d-color" type="color" className="h-10 w-14 cursor-pointer rounded-lg border border-line" value={form.color} onChange={(e) => setForm({ ...form, color: e.target.value.toUpperCase() })} /><input aria-label="Colour hex" className="input font-mono" value={form.color} onChange={(e) => setForm({ ...form, color: e.target.value })} /></div></div>
          <div><label className="label" htmlFor="d-desc">Description</label><textarea id="d-desc" rows={3} className="input" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
          {error && <p role="alert" className="rounded-lg bg-danger-soft px-3 py-2 text-sm text-danger">{error}</p>}
        </div>
      </Modal>

      <Modal open={!!del} onClose={() => setDel(null)} title={`Delete ${del?.name}?`} size="sm"
        footer={<><button className="btn-secondary" onClick={() => setDel(null)}>Cancel</button><button className="btn-danger" disabled={pending} onClick={() => start(async () => {
          const r = await deleteDepartment(del!.id);
          if (!r.ok) return toast.error(r.error);
          toast.success("Department deleted"); setDel(null); router.refresh();
        })}>Delete</button></>}>
        <p className="text-sm text-ink-muted">{del?.total ? `Its ${del.total} task(s) will be kept but no longer belong to a department. ` : ""}{del?.members.length ? `${del.members.length} member(s) will be removed from it. ` : ""}This can&apos;t be undone.</p>
      </Modal>
    </>
  );
}
