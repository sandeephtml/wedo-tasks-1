import type { Metadata } from "next";
import { requireUser } from "@/lib/auth";
import { listTasks, parseFilters } from "@/lib/task-queries";
import { PageHeader } from "@/components/ui/bits";
import { TasksView } from "@/components/tasks/tasks-view";
import { prisma } from "@/lib/db";
import { todayDate } from "@/lib/dates";

export const metadata: Metadata = { title: "My tasks" };

export default async function MyTasksPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const user = await requireUser();
  const filters = { ...parseFilters(await searchParams), mine: true, assignee: undefined };
  const today = todayDate();
  const mine = { OR: [{ assignees: { some: { userId: user.id } } }, { collaborators: { some: { userId: user.id } } }] };
  const [rows, open, overdue, review] = await Promise.all([
    listTasks(user, filters),
    prisma.task.count({ where: { ...mine, status: { category: { not: "DONE" } } } }),
    prisma.task.count({ where: { ...mine, dueDate: { lt: today }, status: { category: { not: "DONE" } } } }),
    prisma.task.count({ where: { ...mine, status: { category: "REVIEW" } } }),
  ]);
  return (
    <>
      <PageHeader
        title={`Hi ${user.name.split(" ")[0]}, here's your work`}
        subtitle={<>{open} open · <span className={overdue ? "font-medium text-danger" : ""}>{overdue} overdue</span> · {review} waiting for review</>}
      />
      <TasksView rows={rows} hideAssignee />
    </>
  );
}
