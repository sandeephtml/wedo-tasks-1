import type { Metadata } from "next";
import { Download } from "lucide-react";
import { requirePagePermission } from "@/lib/auth";
import { getLookups } from "@/lib/lookups";
import { getReportTasks, parseReportFilters, summarize } from "@/lib/reports";
import { PageHeader } from "@/components/ui/bits";

export const metadata: Metadata = { title: "Reports" };

type Row = { key: string; label: string; total: number; open: number; done: number; overdue: number; hours: number };

function Table({ title, rows }: { title: string; rows: Row[] }) {
  return (
    <section className="card overflow-hidden">
      <h2 className="border-b border-line px-4 py-3 font-semibold">{title}</h2>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[520px]">
          <thead className="bg-page/60"><tr><th className="table-th">Name</th><th className="table-th text-right">Total</th><th className="table-th text-right">Open</th><th className="table-th text-right">Done</th><th className="table-th text-right">Overdue</th><th className="table-th text-right">Completion</th><th className="table-th text-right">Est. hours</th></tr></thead>
          <tbody className="divide-y divide-line">
            {rows.map((r) => (
              <tr key={r.key}>
                <td className="table-td font-medium">{r.label}</td><td className="table-td text-right">{r.total}</td><td className="table-td text-right">{r.open}</td>
                <td className="table-td text-right text-success">{r.done}</td><td className={`table-td text-right ${r.overdue ? "font-semibold text-danger" : ""}`}>{r.overdue}</td>
                <td className="table-td text-right">{r.total ? Math.round((r.done / r.total) * 100) : 0}%</td><td className="table-td text-right text-ink-muted">{r.hours ? r.hours.toFixed(1) : "—"}</td>
              </tr>
            ))}
            {!rows.length && <tr><td colSpan={7} className="table-td py-8 text-center text-ink-faint">No tasks match these filters.</td></tr>}
          </tbody>
        </table>
      </div>
    </section>
  );
}

export default async function ReportsPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const user = await requirePagePermission("report.view");
  const sp = await searchParams;
  const f = parseReportFilters(sp);
  const [tasks, lookups] = await Promise.all([getReportTasks(user, f), getLookups()]);
  const s = summarize(tasks);
  const qs = new URLSearchParams(Object.entries({ from: f.from, to: f.to, client: f.client, department: f.department, basis: f.basis }).filter(([, v]) => v) as [string, string][]).toString();
  return (
    <>
      <PageHeader title="Reports" subtitle={`${tasks.length} tasks in this report`} actions={<a href={`/api/reports/tasks?${qs}`} className="btn-primary"><Download className="h-4 w-4" /> Export CSV</a>} />
      <form className="card mb-5 grid grid-cols-2 gap-3 p-4 md:grid-cols-6 md:items-end">
        <div><label className="label" htmlFor="basis">Date by</label><select id="basis" name="basis" defaultValue={f.basis} className="input"><option value="due">Due date</option><option value="created">Created date</option><option value="completed">Completed date</option></select></div>
        <div><label className="label" htmlFor="from">From</label><input id="from" name="from" type="date" defaultValue={f.from} className="input" /></div>
        <div><label className="label" htmlFor="to">To</label><input id="to" name="to" type="date" defaultValue={f.to} className="input" /></div>
        <div><label className="label" htmlFor="client">Client</label><select id="client" name="client" defaultValue={f.client ?? ""} className="input"><option value="">All</option><option value="none">Internal</option>{lookups.clients.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></div>
        <div><label className="label" htmlFor="department">Department</label><select id="department" name="department" defaultValue={f.department ?? ""} className="input"><option value="">All</option>{lookups.departments.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}</select></div>
        <div className="flex gap-2"><button className="btn-primary flex-1">Apply</button><a href="/reports" className="btn-secondary">Reset</a></div>
      </form>
      <div className="space-y-5">
        <Table title="By client" rows={s.byClient} />
        <div className="grid grid-cols-1 gap-5 xl:grid-cols-2">
          <Table title="By department" rows={s.byDepartment} />
          <Table title="By team member" rows={s.byMember} />
        </div>
      </div>
    </>
  );
}
