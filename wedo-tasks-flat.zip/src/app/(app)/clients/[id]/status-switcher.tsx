"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { setClientStatus } from "@/app/actions/clients";
import { useToast } from "@/components/ui/toast";

export function ClientStatusSwitcher({ id, status }: { id: string; status: "ACTIVE" | "ON_HOLD" | "UPCOMING" }) {
  const [pending, start] = useTransition();
  const toast = useToast();
  const router = useRouter();
  return (
    <select aria-label="Client status" className="input h-8 w-auto py-1 text-xs" value={status} disabled={pending}
      onChange={(e) => start(async () => {
        const r = await setClientStatus(id, e.target.value as typeof status);
        if (!r.ok) toast.error(r.error); else { toast.success("Status updated"); router.refresh(); }
      })}>
      <option value="ACTIVE">Active</option><option value="ON_HOLD">On hold</option><option value="UPCOMING">Upcoming</option>
    </select>
  );
}
