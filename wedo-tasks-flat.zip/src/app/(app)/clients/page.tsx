import type { Metadata } from "next";
import Link from "next/link";
import { Building2, Globe, AlertTriangle } from "lucide-react";
import clsx from "clsx";
import type { ClientStatus } from "@prisma/client";
import { prisma } from "@/lib/db";
import { can, requireUser } from "@/lib/auth";
import { visibleClientsWhere, visibleTasksWhere } from "@/lib/task-access";
import { todayDate } from "@/lib/dates";
import { ClientStatusBadge, EmptyState, PageHeader } from "@/components/ui/bits";
import { ClientFormButton } from "@/components/clients/client-form";

export const metadata: Metadata = { title: "Clients" };

const TABS: { key: string; label: string; status?: ClientStatus }[] = [
  { key: "", label: "All" }, { key: "ACTIVE", label: "Active", status: "ACTIVE" }, { key: "ON_HOLD", label: "On hold", status: "ON_HOLD" }, { key: "UPCOMING", label: "Upcoming", status: "UPCOMING" },
];

export default async function ClientsPage({ searchParams }: { searchParams: Promise<{ status?: string; q?: string }> }) {
  const user = await requireUser();
  const { status, q } = await searchParams;
  const tab = TABS.find((t) => t.key === status) ?? TABS[0]!;
  const today = todayDate();
  const visible = visibleTasksWhere(user);
  const [clients, counts] = await Promise.all([
    prisma.client.findMany({
      where: { AND: [visibleClientsWhere(user), tab.status ? { status: tab.status } : {}, q ? { name: { contains: q, mode: "insensitive" } } : {}] },
      orderBy: { name: "asc" },
      include: {
        _count: { select: { tasks: { where: { AND: [visible, { status: { category: { not: "DONE" } } }] } } } },
        tasks: { where: { AND: [visible, { dueDate: { lt: today } }, { status: { category: { not: "DONE" } } }] }, select: { id: true } },
      },
    }),
    prisma.client.groupBy({ by: ["status"], where: visibleClientsWhere(user), _count: true }),
  ]);
  const countFor = (s?: ClientStatus) => (s ? counts.find((c) => c.status === s)?._count ?? 0 : counts.reduce((a, c) => a + c._count, 0));

  return (
    <>
      <PageHeader title="Clients" subtitle={`${countFor("ACTIVE")} active · ${countFor("ON_HOLD")} on hold · ${countFor("UPCOMING")} upcoming`} actions={can(user, "client.manage") ? <ClientFormButton /> : null} />
      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex gap-1 overflow-x-auto rounded-lg border border-line bg-surface p-1">
          {TABS.map((t) => (
            <Link key={t.key} href={t.key ? `/clients?status=${t.key}` : "/clients"} className={clsx("whitespace-nowrap rounded-md px-3 py-1.5 text-sm font-medium", tab.key === t.key ? "bg-brand text-brand-fg" : "text-ink-muted hover:text-ink")}>
              {t.label} <span className="opacity-70">{countFor(t.status)}</span>
            </Link>
          ))}
        </div>
        <form className="sm:w-64">{tab.key && <input type="hidden" name="status" value={tab.key} />}<input name="q" defaultValue={q} placeholder="Search clients…" className="input h-9" aria-label="Search clients" /></form>
      </div>
      {clients.length ? (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {clients.map((c) => (
            <Link key={c.id} href={`/clients/${c.id}`} className="card group p-4 transition-shadow hover:shadow-pop">
              <div className="flex items-start justify-between gap-2">
                <div className="flex min-w-0 items-center gap-3">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-brand-soft font-display font-bold text-brand">{c.name[0]}</span>
                  <div className="min-w-0">
                    <p className="truncate font-semibold group-hover:text-brand">{c.name}</p>
                    {c.website ? <p className="flex items-center gap-1 truncate text-xs text-ink-muted"><Globe className="h-3 w-3" />{c.website.replace(/^https?:\/\/(www\.)?/, "").replace(/\/$/, "")}</p> : <p className="text-xs text-ink-faint">No website</p>}
                  </div>
                </div>
                <ClientStatusBadge status={c.status} />
              </div>
              {c.services.length > 0 && (
                <div className="mt-3 flex flex-wrap gap-1">
                  {c.services.slice(0, 5).map((s) => <span key={s} className="badge bg-page text-ink-muted">{s}</span>)}
                  {c.services.length > 5 && <span className="badge bg-page text-ink-faint">+{c.services.length - 5}</span>}
                </div>
              )}
              <div className="mt-4 flex items-center gap-4 border-t border-line pt-3 text-xs text-ink-muted">
                <span><strong className="text-ink">{c._count.tasks}</strong> open tasks</span>
                {c.tasks.length > 0 && <span className="flex items-center gap-1 font-medium text-danger"><AlertTriangle className="h-3 w-3" />{c.tasks.length} overdue</span>}
              </div>
            </Link>
          ))}
        </div>
      ) : (
        <div className="card"><EmptyState icon={<Building2 className="h-10 w-10" />} title="No clients found">{can(user, "client.manage") ? "Add your first client to get started." : "Clients appear here once you have tasks for them."}</EmptyState></div>
      )}
    </>
  );
}
