"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import clsx from "clsx";
import { Copy, KeyRound, Loader2, MoreHorizontal, Pencil, Plus, UserCheck, UserX } from "lucide-react";
import { Avatar, ColorBadge, PageHeader } from "@/components/ui/bits";
import { Modal } from "@/components/ui/modal";
import { useApp } from "@/components/app-context";
import { useToast } from "@/components/ui/toast";
import { createUser, resetUserPassword, setUserActive, updateUser } from "@/app/actions/users";

type U = { id: string; name: string; email: string; title: string; roleId: string; roleName: string; roleRank: number; departmentIds: string[]; isActive: boolean; mustChangePassword: boolean; lastLogin: string; openTasks: number };
type R = { id: string; name: string; rank: number };
const ADMIN_RANK = 80;

export function TeamTable({ users, roles, meId, meRank, canManage, canManageAdmins }: { users: U[]; roles: R[]; meId: string; meRank: number; canManage: boolean; canManageAdmins: boolean }) {
  const { lookups } = useApp();
  const toast = useToast();
  const router = useRouter();
  const [pending, start] = useTransition();
  const [edit, setEdit] = useState<U | "new" | null>(null);
  const [secret, setSecret] = useState<{ name: string; email: string; password: string } | null>(null);
  const [confirm, setConfirm] = useState<{ user: U; action: "reset" | "deactivate" } | null>(null);
  const [menu, setMenu] = useState<string | null>(null);
  const assignableRoles = roles.filter((r) => r.rank <= meRank && (canManageAdmins || r.rank < ADMIN_RANK));
  const canTouch = (u: U) => canManage && u.id !== meId && u.roleRank <= meRank && (canManageAdmins || u.roleRank < ADMIN_RANK);
  const dept = (id: string) => lookups.departments.find((d) => d.id === id);

  const doReset = (u: U) => start(async () => {
    const r = await resetUserPassword(u.id);
    setConfirm(null);
    if (!r.ok) return toast.error(r.error);
    setSecret({ name: u.name, email: u.email, password: r.data!.tempPassword });
  });
  const doActive = (u: U, active: boolean) => start(async () => {
    const r = await setUserActive(u.id, active);
    setConfirm(null);
    if (!r.ok) return toast.error(r.error);
    toast.success(active ? `${u.name} reactivated` : `${u.name} deactivated and signed out`);
    router.refresh();
  });

  return (
    <>
      <PageHeader title="Team" subtitle={`${users.filter((u) => u.isActive).length} active people`}
        actions={canManage ? <button className="btn-primary" onClick={() => setEdit("new")}><Plus className="h-4 w-4" /> Add person</button> : null} />
      <div className="card overflow-visible">
        <div className="hidden grid-cols-[minmax(0,2fr)_140px_minmax(0,2fr)_90px_110px_44px] gap-4 border-b border-line px-4 py-2.5 text-[11px] font-semibold uppercase tracking-wide text-ink-faint lg:grid">
          <span>Person</span><span>Role</span><span>Departments</span><span>Open tasks</span><span>Last login</span><span />
        </div>
        <ul className="divide-y divide-line">
          {users.map((u) => (
            <li key={u.id} className={clsx("grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 px-4 py-3 lg:grid-cols-[minmax(0,2fr)_140px_minmax(0,2fr)_90px_110px_44px] lg:gap-4", !u.isActive && "opacity-60")}>
              <div className="flex min-w-0 items-center gap-3">
                <Avatar name={u.name} size={36} />
                <div className="min-w-0">
                  <p className="flex items-center gap-2 truncate font-medium">{u.name}{!u.isActive && <span className="badge bg-page text-ink-muted">Deactivated</span>}{u.isActive && u.mustChangePassword && <span className="badge bg-warning-soft text-warning">Temp password</span>}</p>
                  <p className="truncate text-xs text-ink-muted">{u.title ? `${u.title} · ` : ""}{u.email}</p>
                  <div className="mt-1 flex flex-wrap gap-1 lg:hidden"><span className="badge bg-brand-soft text-brand">{u.roleName}</span>{u.departmentIds.map((id) => dept(id) && <ColorBadge key={id} color={dept(id)!.color}>{dept(id)!.name}</ColorBadge>)}</div>
                </div>
              </div>
              <span className="hidden lg:block"><span className="badge bg-brand-soft text-brand">{u.roleName}</span></span>
              <div className="hidden flex-wrap gap-1 lg:flex">{u.departmentIds.length ? u.departmentIds.map((id) => dept(id) && <ColorBadge key={id} color={dept(id)!.color}>{dept(id)!.name}</ColorBadge>) : <span className="text-xs text-ink-faint">—</span>}</div>
              <span className="hidden text-sm lg:block">{u.openTasks}</span>
              <span className="hidden text-xs text-ink-muted lg:block">{u.lastLogin}</span>
              <div className="relative justify-self-end">
                {canTouch(u) && (
                  <button aria-label={`Actions for ${u.name}`} className="btn-ghost px-2" onClick={() => setMenu(menu === u.id ? null : u.id)}><MoreHorizontal className="h-4 w-4" /></button>
                )}
                {menu === u.id && (
                  <div className="absolute right-0 z-30 mt-1 w-48 rounded-xl border border-line bg-surface py-1 shadow-pop" onMouseLeave={() => setMenu(null)}>
                    <button className="flex w-full items-center gap-2 px-3 py-2 text-sm hover:bg-page" onClick={() => { setMenu(null); setEdit(u); }}><Pencil className="h-4 w-4 text-ink-faint" /> Edit</button>
                    <button className="flex w-full items-center gap-2 px-3 py-2 text-sm hover:bg-page" onClick={() => { setMenu(null); setConfirm({ user: u, action: "reset" }); }}><KeyRound className="h-4 w-4 text-ink-faint" /> Reset password</button>
                    {u.isActive
                      ? <button className="flex w-full items-center gap-2 px-3 py-2 text-sm text-danger hover:bg-page" onClick={() => { setMenu(null); setConfirm({ user: u, action: "deactivate" }); }}><UserX className="h-4 w-4" /> Deactivate</button>
                      : <button className="flex w-full items-center gap-2 px-3 py-2 text-sm text-success hover:bg-page" onClick={() => { setMenu(null); doActive(u, true); }}><UserCheck className="h-4 w-4" /> Reactivate</button>}
                  </div>
                )}
              </div>
            </li>
          ))}
        </ul>
      </div>

      {edit && (
        <UserForm
          user={edit === "new" ? null : edit}
          roles={assignableRoles}
          isSelf={edit !== "new" && edit.id === meId}
          onClose={() => setEdit(null)}
          onCreated={(name, email, password) => setSecret({ name, email, password })}
        />
      )}

      <Modal open={!!confirm} onClose={() => setConfirm(null)} title={confirm?.action === "reset" ? `Reset ${confirm?.user.name}'s password?` : `Deactivate ${confirm?.user.name}?`} size="sm"
        footer={<>
          <button className="btn-secondary" onClick={() => setConfirm(null)}>Cancel</button>
          <button className={confirm?.action === "reset" ? "btn-primary" : "btn-danger"} disabled={pending}
            onClick={() => confirm && (confirm.action === "reset" ? doReset(confirm.user) : doActive(confirm.user, false))}>
            {pending && <Loader2 className="h-4 w-4 animate-spin" />}{confirm?.action === "reset" ? "Generate new password" : "Deactivate"}
          </button></>}>
        <p className="text-sm text-ink-muted">
          {confirm?.action === "reset"
            ? "A new temporary password will be generated and shown once. They'll be signed out everywhere and asked to choose their own password at next sign-in."
            : "They will be signed out immediately and won't be able to sign in. Their tasks and history are kept. You can reactivate them later."}
        </p>
      </Modal>

      <Modal open={!!secret} onClose={() => setSecret(null)} title="Temporary password" size="sm" footer={<button className="btn-primary" onClick={() => setSecret(null)}>Done</button>}>
        <p className="text-sm text-ink-muted">Share these details with <strong className="text-ink">{secret?.name}</strong> privately. This password is shown only once.</p>
        <div className="mt-3 space-y-2 rounded-lg bg-page p-3 font-mono text-sm">
          <div>Email: {secret?.email}</div>
          <div className="flex items-center justify-between gap-2">Password: <span data-testid="temp-password" className="font-semibold">{secret?.password}</span>
            <button aria-label="Copy password" className="btn-ghost px-2" onClick={() => { navigator.clipboard?.writeText(secret?.password ?? ""); toast.success("Copied"); }}><Copy className="h-4 w-4" /></button></div>
        </div>
      </Modal>
    </>
  );
}

function UserForm({ user, roles, isSelf, onClose, onCreated }: { user: U | null; roles: R[]; isSelf: boolean; onClose: () => void; onCreated: (n: string, e: string, p: string) => void }) {
  const { lookups } = useApp();
  const toast = useToast();
  const router = useRouter();
  const memberRole = roles.find((r) => r.name === "Team Member") ?? roles[roles.length - 1];
  const [v, setV] = useState({ name: user?.name ?? "", email: user?.email ?? "", title: user?.title ?? "", roleId: user?.roleId ?? memberRole?.id ?? "", departmentIds: user?.departmentIds ?? [] as string[], password: "" });
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();
  const roleOptions = user && !roles.some((r) => r.id === user.roleId) ? [{ id: user.roleId, name: user.roleName, rank: user.roleRank }, ...roles] : roles;

  const save = () => start(async () => {
    setError(null);
    const payload = { name: v.name, email: v.email, title: v.title, roleId: v.roleId, departmentIds: v.departmentIds };
    if (user) {
      const r = await updateUser(user.id, payload);
      if (!r.ok) return setError(r.error);
      toast.success("Saved");
    } else {
      const r = await createUser({ ...payload, password: v.password || undefined });
      if (!r.ok) return setError(r.error);
      onCreated(v.name, v.email.trim().toLowerCase(), r.data!.tempPassword);
    }
    onClose();
    router.refresh();
  });

  return (
    <Modal open onClose={onClose} title={user ? `Edit ${user.name}` : "Add person"}
      footer={<><button className="btn-secondary" onClick={onClose}>Cancel</button><button className="btn-primary" disabled={pending || !v.name.trim() || !v.email.trim()} onClick={save}>{pending && <Loader2 className="h-4 w-4 animate-spin" />}{user ? "Save" : "Create login"}</button></>}>
      <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); save(); }}>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div><label className="label" htmlFor="u-name">Name *</label><input id="u-name" className="input" value={v.name} onChange={(e) => setV({ ...v, name: e.target.value })} /></div>
          <div><label className="label" htmlFor="u-title">Job title</label><input id="u-title" className="input" placeholder="e.g. Technical SEO Specialist" value={v.title} onChange={(e) => setV({ ...v, title: e.target.value })} /></div>
          <div><label className="label" htmlFor="u-email">Email *</label><input id="u-email" type="email" className="input" value={v.email} onChange={(e) => setV({ ...v, email: e.target.value })} /></div>
          <div><label className="label" htmlFor="u-role">Role</label>
            <select id="u-role" className="input" value={v.roleId} disabled={isSelf} onChange={(e) => setV({ ...v, roleId: e.target.value })}>
              {roleOptions.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
            </select>
            {isSelf && <p className="mt-1 text-[11px] text-ink-faint">You can&apos;t change your own role.</p>}
          </div>
        </div>
        <div>
          <span className="label">Departments (one person can be in several)</span>
          <div className="flex flex-wrap gap-1.5">
            {lookups.departments.map((d) => {
              const on = v.departmentIds.includes(d.id);
              return <button type="button" key={d.id} onClick={() => setV({ ...v, departmentIds: on ? v.departmentIds.filter((x) => x !== d.id) : [...v.departmentIds, d.id] })}
                className={clsx("rounded-full border px-2.5 py-1 text-xs font-medium", on ? "border-brand bg-brand text-brand-fg" : "border-line text-ink-muted hover:border-brand/50")}>{d.name}</button>;
            })}
          </div>
        </div>
        {!user && (
          <div><label className="label" htmlFor="u-pw">Temporary password</label>
            <input id="u-pw" type="text" className="input font-mono" autoComplete="off" placeholder="Leave blank to generate a secure one" value={v.password} onChange={(e) => setV({ ...v, password: e.target.value })} />
            <p className="mt-1 text-[11px] text-ink-faint">They&apos;ll be asked to change it at first sign-in. Min 10 characters with a letter and a number.</p></div>
        )}
        {error && <p role="alert" className="rounded-lg bg-danger-soft px-3 py-2 text-sm text-danger">{error}</p>}
        <button type="submit" className="hidden" />
      </form>
    </Modal>
  );
}
