"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState, useTransition } from "react";
import clsx from "clsx";
import {
  ArrowLeft, Pencil, Trash2, Send, CheckCircle2, RotateCcw, Plus, ExternalLink, Link2, Calendar, Clock, Building2,
  Network, Flag, User, Repeat, Loader2, History,
} from "lucide-react";
import { useApp } from "@/components/app-context";
import { useToast } from "@/components/ui/toast";
import { Avatar, ColorBadge } from "@/components/ui/bits";
import { Modal } from "@/components/ui/modal";
import { formatDay, isOverdue, todayDate } from "@/lib/dates";
import { StatusSelect, PriorityBadge } from "@/components/tasks/status-pill";
import { UserPicker } from "@/components/tasks/user-picker";
import { TaskFormModal } from "@/components/tasks/task-form";
import { CommentDialog } from "@/components/tasks/revision-dialog";
import {
  addChecklistItem, addTaskLink, changeTaskStatus, deleteChecklistItem, deleteTask, deleteTaskLink, setTaskAssignees, toggleChecklistItem,
} from "@/app/actions/tasks";
import { Comments } from "./comments";

export type TaskDetailData = {
  id: string; number: number; title: string; description: string | null; statusId: string; statusCategory: string;
  priorityId: string; clientId: string | null; departmentId: string | null; startDate: string; dueDate: string;
  estimateHours: number | null; assigneeIds: string[]; collaboratorIds: string[]; createdBy: string; createdAt: string;
  updatedAt: string; completedAt: string | null; recurring: string | null;
  checklist: { id: string; text: string; done: boolean }[];
  links: { id: string; url: string; label: string | null; addedBy: string }[];
  comments: { id: string; body: string; kind: string; author: string; authorId: string; at: string; ago: string }[];
  activity: { id: string; actor: string; message: string; ago: string; at: string }[];
};
type Perms = { editDetails: boolean; work: boolean; involved: boolean; assign: boolean; approve: boolean; remove: boolean };

export function TaskDetail({ task, perms }: { task: TaskDetailData; perms: Perms }) {
  const { lookups } = useApp();
  const toast = useToast();
  const router = useRouter();
  const [busy, start] = useTransition();
  const [editOpen, setEditOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [dialog, setDialog] = useState<null | { statusId: string; kind: "revision" | "approve" }>(null);
  const [newItem, setNewItem] = useState("");
  const [link, setLink] = useState({ url: "", label: "" });
  const [linkOpen, setLinkOpen] = useState(false);
  const [checklist, setChecklist] = useState(task.checklist);
  useEffect(() => setChecklist(task.checklist), [task.checklist]);

  const status = lookups.statuses.find((s) => s.id === task.statusId);
  const byCat = (c: string) => lookups.statuses.find((s) => s.category === c);
  const reviewStatus = byCat("REVIEW"), doneStatus = byCat("DONE"), revisionStatus = byCat("REVISION");
  const client = lookups.clients.find((c) => c.id === task.clientId);
  const dept = lookups.departments.find((d) => d.id === task.departmentId);
  const nameOf = (id: string) => lookups.users.find((u) => u.id === id)?.name ?? "Former user";
  const overdue = isOverdue(task.dueDate || null, task.statusCategory === "DONE", todayDate());
  const doneCount = checklist.filter((c) => c.done).length;

  const run = (fn: () => Promise<{ ok: boolean; error?: string }>, success?: string) =>
    start(async () => {
      const r = await fn().catch(() => ({ ok: false, error: "Couldn't reach the server. Please try again." }));
      if (!r.ok) toast.error(r.error ?? "Failed");
      else { if (success) toast.success(success); router.refresh(); }
    });

  const onStatus = (statusId: string) => {
    const to = lookups.statuses.find((s) => s.id === statusId);
    if (to?.category === "REVISION") return setDialog({ statusId, kind: "revision" });
    run(() => changeTaskStatus(task.id, statusId), `Moved to ${to?.name}`);
  };

  return (
    <div>
      <div className="mb-4 flex items-center justify-between gap-2">
        <button onClick={() => (history.length > 1 ? router.back() : router.push("/tasks"))} className="btn-ghost btn-sm -ml-2"><ArrowLeft className="h-4 w-4" /> Back</button>
        <div className="flex items-center gap-2">
          {perms.editDetails && <button className="btn-secondary btn-sm" onClick={() => setEditOpen(true)}><Pencil className="h-3.5 w-3.5" /> Edit</button>}
          {perms.remove && <button className="btn-ghost btn-sm text-danger" onClick={() => setDeleteOpen(true)}><Trash2 className="h-3.5 w-3.5" /> Delete</button>}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-5 xl:grid-cols-[minmax(0,1fr)_340px]">
        <div className="space-y-5">
          <div className="card p-5">
            <div className="flex flex-wrap items-center gap-2 text-xs text-ink-muted">
              <span className="font-medium text-ink-faint">#{task.number}</span>
              <StatusSelect value={task.statusId} onChange={onStatus} disabled={busy} />
              <PriorityBadge id={task.priorityId} />
              {overdue && <span className="badge bg-danger-soft text-danger">Overdue</span>}
              {task.recurring && <span className="badge bg-page text-ink-muted"><Repeat className="h-3 w-3" /> {task.recurring.toLowerCase()}</span>}
              {busy && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
            </div>
            <h1 className="mt-3 font-display text-xl font-semibold leading-tight sm:text-2xl">{task.title}</h1>

            {/* Review workflow */}
            <div className="mt-4 flex flex-wrap gap-2">
              {(task.statusCategory === "OPEN" || task.statusCategory === "REVISION") && reviewStatus && (perms.involved || perms.approve) && (
                <button className="btn-primary btn-sm" disabled={busy} onClick={() => run(() => changeTaskStatus(task.id, reviewStatus.id), "Submitted for review")}>
                  <Send className="h-3.5 w-3.5" /> Submit for review
                </button>
              )}
              {task.statusCategory === "REVIEW" && perms.approve && doneStatus && (
                <button className="btn btn-sm bg-success text-white hover:opacity-90" disabled={busy} onClick={() => setDialog({ statusId: doneStatus.id, kind: "approve" })}>
                  <CheckCircle2 className="h-3.5 w-3.5" /> Approve
                </button>
              )}
              {task.statusCategory === "REVIEW" && perms.approve && revisionStatus && (
                <button className="btn-secondary btn-sm text-danger" disabled={busy} onClick={() => setDialog({ statusId: revisionStatus.id, kind: "revision" })}>
                  <RotateCcw className="h-3.5 w-3.5" /> Request revision
                </button>
              )}
              {task.statusCategory === "REVIEW" && !perms.approve && <p className="text-xs text-ink-muted">Waiting for a manager to review.</p>}
              {task.statusCategory === "DONE" && task.completedAt && <p className="flex items-center gap-1 text-xs text-success"><CheckCircle2 className="h-3.5 w-3.5" /> Completed {task.completedAt}</p>}
            </div>

            <div className="mt-5 border-t border-line pt-4">
              <h2 className="mb-2 text-xs font-semibold uppercase tracking-wide text-ink-faint">Description</h2>
              {task.description ? <p className="whitespace-pre-wrap text-sm leading-relaxed">{task.description}</p> : <p className="text-sm text-ink-faint">No description.</p>}
            </div>
          </div>

          {/* Checklist */}
          <div className="card p-5">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="font-semibold">Checklist</h2>
              {checklist.length > 0 && <span className="text-xs text-ink-muted">{doneCount}/{checklist.length} done</span>}
            </div>
            {checklist.length > 0 && (
              <div className="mb-3 h-1.5 overflow-hidden rounded-full bg-page"><div className="h-full rounded-full bg-success transition-all" style={{ width: `${(doneCount / checklist.length) * 100}%` }} /></div>
            )}
            <ul className="space-y-1">
              {checklist.map((c) => (
                <li key={c.id} className="group flex items-center gap-3 rounded-lg px-2 py-1.5 hover:bg-page">
                  <input type="checkbox" aria-label={c.text} className="h-4 w-4 cursor-pointer accent-[rgb(var(--brand))]" checked={c.done} disabled={!perms.work}
                    onChange={async (e) => {
                      const done = e.target.checked;
                      const prev = checklist;
                      setChecklist((l) => l.map((x) => (x.id === c.id ? { ...x, done } : x)));
                      const r = await toggleChecklistItem(c.id, done).catch(() => ({ ok: false as const, error: "Couldn't reach the server. Change undone." }));
                      if (!r.ok) { setChecklist(prev); toast.error(r.error); } else router.refresh();
                    }} />
                  <span className={clsx("flex-1 text-sm", c.done && "text-ink-faint line-through")}>{c.text}</span>
                  {perms.work && <button aria-label="Delete item" onClick={() => run(() => deleteChecklistItem(c.id))} className="text-ink-faint opacity-0 hover:text-danger group-hover:opacity-100"><Trash2 className="h-3.5 w-3.5" /></button>}
                </li>
              ))}
            </ul>
            {perms.work && (
              <form className="mt-2 flex gap-2" onSubmit={(e) => { e.preventDefault(); if (!newItem.trim()) return; const t = newItem; setNewItem(""); run(() => addChecklistItem(task.id, t)); }}>
                <input className="input" placeholder="Add an item…" value={newItem} onChange={(e) => setNewItem(e.target.value)} />
                <button className="btn-secondary" disabled={!newItem.trim()} aria-label="Add checklist item"><Plus className="h-4 w-4" /></button>
              </form>
            )}
          </div>

          {/* Links */}
          <div className="card p-5">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="font-semibold">Links</h2>
              {perms.work && <button className="btn-ghost btn-sm" onClick={() => setLinkOpen((o) => !o)}><Link2 className="h-3.5 w-3.5" /> Add link</button>}
            </div>
            {linkOpen && (
              <form className="mb-3 flex flex-col gap-2 sm:flex-row" onSubmit={(e) => { e.preventDefault(); const l = link; setLink({ url: "", label: "" }); setLinkOpen(false); run(() => addTaskLink(task.id, l.url, l.label), "Link added"); }}>
                <input className="input" required placeholder="https://drive.google.com/…" value={link.url} onChange={(e) => setLink((l) => ({ ...l, url: e.target.value }))} />
                <input className="input sm:max-w-[200px]" placeholder="Label (optional)" value={link.label} onChange={(e) => setLink((l) => ({ ...l, label: e.target.value }))} />
                <button className="btn-primary">Save</button>
              </form>
            )}
            {task.links.length ? (
              <ul className="space-y-1">
                {task.links.map((l) => (
                  <li key={l.id} className="group flex items-center gap-3 rounded-lg px-2 py-2 hover:bg-page">
                    <ExternalLink className="h-4 w-4 shrink-0 text-ink-faint" />
                    <a href={l.url} target="_blank" rel="noopener noreferrer nofollow" className="min-w-0 flex-1 truncate text-sm text-brand hover:underline">{l.label || l.url}</a>
                    <span className="hidden text-xs text-ink-faint sm:inline">{l.addedBy}</span>
                    {perms.work && <button aria-label="Delete link" onClick={() => run(() => deleteTaskLink(l.id))} className="text-ink-faint opacity-0 hover:text-danger group-hover:opacity-100"><Trash2 className="h-3.5 w-3.5" /></button>}
                  </li>
                ))}
              </ul>
            ) : !linkOpen && <p className="text-sm text-ink-faint">No links yet. Add Google Drive folders, briefs or references.</p>}
          </div>

          <Comments taskId={task.id} comments={task.comments} />
        </div>

        {/* Sidebar */}
        <aside className="space-y-5">
          <div className="card divide-y divide-line">
            <Row icon={<User className="h-4 w-4" />} label="Assignees">
              {perms.assign ? (
                <UserPicker value={task.assigneeIds} departmentId={task.departmentId} label="Assignees" onChange={(ids) => run(() => setTaskAssignees(task.id, ids))} />
              ) : (
                <People ids={task.assigneeIds} nameOf={nameOf} empty="Unassigned" />
              )}
            </Row>
            <Row icon={<User className="h-4 w-4" />} label="Collaborators"><People ids={task.collaboratorIds} nameOf={nameOf} empty="None" /></Row>
            <Row icon={<Building2 className="h-4 w-4" />} label="Client">{client ? <Link href={`/clients/${client.id}`} className="text-brand hover:underline">{client.name}</Link> : "Internal"}</Row>
            <Row icon={<Network className="h-4 w-4" />} label="Department">{dept ? <ColorBadge color={dept.color}>{dept.name}</ColorBadge> : "—"}</Row>
            <Row icon={<Flag className="h-4 w-4" />} label="Priority"><PriorityBadge id={task.priorityId} /></Row>
            <Row icon={<Calendar className="h-4 w-4" />} label="Start date">{task.startDate ? formatDay(task.startDate) : "—"}</Row>
            <Row icon={<Calendar className="h-4 w-4" />} label="Due date"><span className={clsx(overdue && "font-semibold text-danger")}>{task.dueDate ? formatDay(task.dueDate) : "—"}</span></Row>
            <Row icon={<Clock className="h-4 w-4" />} label="Estimate">{task.estimateHours != null ? `${task.estimateHours} h` : "—"}</Row>
            <div className="px-4 py-3 text-xs text-ink-muted">Created by {task.createdBy} · {task.createdAt}<br />Updated {task.updatedAt} · Status: {status?.name}</div>
          </div>

          <div className="card p-4">
            <h2 className="mb-3 flex items-center gap-2 text-sm font-semibold"><History className="h-4 w-4 text-ink-faint" /> Activity</h2>
            <ol className="relative space-y-3 border-l border-line pl-4">
              {task.activity.map((a) => (
                <li key={a.id} className="text-xs">
                  <span className="absolute -left-[5px] mt-1 h-2.5 w-2.5 rounded-full border-2 border-surface bg-line" />
                  <span className="font-medium text-ink">{a.actor}</span> <span className="text-ink-muted">{a.message}</span>
                  <span className="block text-ink-faint" title={a.at}>{a.ago}</span>
                </li>
              ))}
              {!task.activity.length && <li className="text-xs text-ink-faint">No activity yet.</li>}
            </ol>
          </div>
        </aside>
      </div>

      {editOpen && (
        <TaskFormModal
          open={editOpen}
          onClose={() => setEditOpen(false)}
          taskId={task.id}
          initial={{
            title: task.title, description: task.description ?? "", clientId: task.clientId ?? "", departmentId: task.departmentId ?? "",
            priorityId: task.priorityId, startDate: task.startDate, dueDate: task.dueDate, estimateHours: task.estimateHours?.toString() ?? "",
            assigneeIds: task.assigneeIds, collaboratorIds: task.collaboratorIds,
          }}
        />
      )}
      <CommentDialog
        open={!!dialog}
        title={dialog?.kind === "revision" ? "Request revisions" : "Approve task"}
        required={dialog?.kind === "revision"}
        confirmLabel={dialog?.kind === "revision" ? "Send back" : "Approve"}
        onCancel={() => setDialog(null)}
        onConfirm={(comment) => {
          const d = dialog!;
          setDialog(null);
          run(() => changeTaskStatus(task.id, d.statusId, comment), d.kind === "revision" ? "Sent back for revision" : "Task approved");
        }}
      />
      <Modal open={deleteOpen} onClose={() => setDeleteOpen(false)} title="Delete task?" size="sm"
        footer={<><button className="btn-secondary" onClick={() => setDeleteOpen(false)}>Cancel</button>
          <button className="btn-danger" disabled={busy} onClick={() => start(async () => {
            const r = await deleteTask(task.id);
            if (!r.ok) return toast.error(r.error);
            toast.success("Task deleted");
            router.push("/tasks");
            router.refresh();
          })}>Delete</button></>}>
        <p className="text-sm text-ink-muted">“{task.title}” and its checklist, comments and links will be permanently deleted. This can’t be undone.</p>
      </Modal>
    </div>
  );
}

function Row({ icon, label, children }: { icon: React.ReactNode; label: string; children: React.ReactNode }) {
  return (
    <div className="grid grid-cols-[120px_minmax(0,1fr)] items-center gap-2 px-4 py-2.5 text-sm">
      <span className="flex items-center gap-2 text-ink-muted">{icon}{label}</span>
      <div className="min-w-0">{children}</div>
    </div>
  );
}

function People({ ids, nameOf, empty }: { ids: string[]; nameOf: (id: string) => string; empty: string }) {
  if (!ids.length) return <span className="text-ink-faint">{empty}</span>;
  return (
    <div className="flex flex-wrap gap-1.5">
      {ids.map((id) => <span key={id} className="flex items-center gap-1.5 rounded-full bg-page py-0.5 pl-0.5 pr-2 text-xs"><Avatar name={nameOf(id)} size={20} />{nameOf(id)}</span>)}
    </div>
  );
}
