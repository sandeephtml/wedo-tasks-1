import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { can, requireUser } from "@/lib/auth";
import { canEditTaskDetails, canWorkOnTask, isInvolved, visibleTasksWhere } from "@/lib/task-access";
import { formatDateTime, timeAgo, toInputDate } from "@/lib/dates";
import { TaskDetail } from "./task-detail";

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }): Promise<Metadata> {
  const [{ id }, user] = await Promise.all([params, requireUser()]);
  const t = await prisma.task.findFirst({ where: { AND: [{ id }, visibleTasksWhere(user)] }, select: { number: true, title: true } });
  return { title: t ? `#${t.number} ${t.title}` : "Task" };
}

export default async function TaskPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await requireUser();
  const { id } = await params;
  const task = await prisma.task.findFirst({
    where: { AND: [{ id }, visibleTasksWhere(user)] },
    include: {
      status: true,
      createdBy: { select: { name: true } },
      assignees: { select: { userId: true } },
      collaborators: { select: { userId: true } },
      checklist: { orderBy: [{ order: "asc" }, { createdAt: "asc" }] },
      links: { orderBy: { createdAt: "asc" }, include: { addedBy: { select: { name: true } } } },
      comments: { orderBy: { createdAt: "asc" }, include: { author: { select: { name: true } } } },
      activity: { orderBy: { createdAt: "desc" }, take: 50, include: { actor: { select: { name: true } } } },
      recurring: { select: { id: true, frequency: true } },
    },
  });
  if (!task) notFound();

  const data = {
    id: task.id, number: task.number, title: task.title, description: task.description,
    statusId: task.statusId, statusCategory: task.status.category, priorityId: task.priorityId,
    clientId: task.clientId, departmentId: task.departmentId,
    startDate: toInputDate(task.startDate), dueDate: toInputDate(task.dueDate), estimateHours: task.estimateHours,
    assigneeIds: task.assignees.map((a) => a.userId), collaboratorIds: task.collaborators.map((c) => c.userId),
    createdBy: task.createdBy.name, createdAt: formatDateTime(task.createdAt), updatedAt: timeAgo(task.updatedAt),
    completedAt: task.completedAt ? formatDateTime(task.completedAt) : null,
    recurring: task.recurring?.frequency ?? null,
    checklist: task.checklist.map((c) => ({ id: c.id, text: c.text, done: c.done })),
    links: task.links.map((l) => ({ id: l.id, url: l.url, label: l.label, addedBy: l.addedBy.name })),
    comments: task.comments.map((c) => ({ id: c.id, body: c.body, kind: c.kind, author: c.author.name, authorId: c.authorId, at: formatDateTime(c.createdAt), ago: timeAgo(c.createdAt) })),
    activity: task.activity.map((a) => ({ id: a.id, actor: a.actor?.name ?? "System", message: a.message, ago: timeAgo(a.createdAt), at: formatDateTime(a.createdAt) })),
  };
  const perms = {
    editDetails: canEditTaskDetails(user, task),
    work: canWorkOnTask(user, task),
    involved: isInvolved(user, task),
    assign: can(user, "task.assign"),
    approve: can(user, "task.approve"),
    remove: can(user, "task.delete"),
  };
  return <TaskDetail task={data} perms={perms} />;
}
