"use client";

import { useMemo, useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import clsx from "clsx";
import { Loader2, MessageSquare, Trash2 } from "lucide-react";
import { useApp } from "@/components/app-context";
import { useToast } from "@/components/ui/toast";
import { Avatar } from "@/components/ui/bits";
import { addComment, deleteComment } from "@/app/actions/comments";

type C = { id: string; body: string; kind: string; author: string; authorId: string; at: string; ago: string };

function renderBody(body: string) {
  return body.split(/(@[A-Za-z][\w.-]*)/g).map((part, i) => (part.startsWith("@") ? <span key={i} className="font-medium text-brand">{part}</span> : part));
}

export function Comments({ taskId, comments }: { taskId: string; comments: C[] }) {
  const { me, lookups, can } = useApp();
  const toast = useToast();
  const router = useRouter();
  const [text, setText] = useState("");
  const [pending, start] = useTransition();
  const ref = useRef<HTMLTextAreaElement>(null);

  const mentionQuery = useMemo(() => /(?:^|\s)@([\w.-]*)$/.exec(text)?.[1], [text]);
  const suggestions = mentionQuery !== undefined
    ? lookups.users.filter((u) => u.id !== me.id && u.name.toLowerCase().startsWith(mentionQuery.toLowerCase())).slice(0, 5)
    : [];

  const submit = () => {
    if (!text.trim()) return;
    start(async () => {
      const r = await addComment(taskId, text);
      if (!r.ok) return toast.error(r.error);
      setText("");
      router.refresh();
    });
  };

  return (
    <div className="card p-5">
      <h2 className="mb-4 flex items-center gap-2 font-semibold"><MessageSquare className="h-4 w-4 text-ink-faint" /> Comments <span className="text-sm font-normal text-ink-faint">{comments.length}</span></h2>
      <ul className="space-y-4">
        {comments.map((c) => (
          <li key={c.id} className="group flex gap-3">
            <Avatar name={c.author} size={32} />
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2 text-xs">
                <span className="font-semibold text-ink">{c.author}</span>
                <span className="text-ink-faint" title={c.at}>{c.ago}</span>
                {c.kind === "revision" && <span className="badge bg-danger-soft text-danger">Revision requested</span>}
                {c.kind === "approval" && <span className="badge bg-success-soft text-success">Approved</span>}
                {(c.authorId === me.id || can("task.edit_any")) && (
                  <button aria-label="Delete comment" className="ml-auto text-ink-faint opacity-0 hover:text-danger group-hover:opacity-100"
                    onClick={() => start(async () => { const r = await deleteComment(c.id); if (!r.ok) toast.error(r.error); else router.refresh(); })}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                )}
              </div>
              <p className={clsx("mt-1 whitespace-pre-wrap break-words rounded-lg px-3 py-2 text-sm", c.kind === "revision" ? "bg-danger-soft/60" : c.kind === "approval" ? "bg-success-soft/60" : "bg-page")}>{renderBody(c.body)}</p>
            </div>
          </li>
        ))}
        {!comments.length && <li className="text-sm text-ink-faint">No comments yet. Start the conversation. Use @name to mention someone.</li>}
      </ul>
      <div className="relative mt-4 flex gap-3">
        <Avatar name={me.name} size={32} />
        <div className="flex-1">
          <textarea
            ref={ref}
            rows={3}
            className="input"
            placeholder="Write a comment… use @name to mention"
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) submit(); }}
            aria-label="Write a comment"
          />
          {suggestions.length > 0 && (
            <div className="absolute z-20 mt-1 w-56 rounded-lg border border-line bg-surface p-1 shadow-pop">
              {suggestions.map((u) => (
                <button key={u.id} type="button" className="flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-sm hover:bg-page"
                  onClick={() => { setText((t) => t.replace(/@([\w.-]*)$/, `@${u.name.split(" ")[0]} `)); ref.current?.focus(); }}>
                  <Avatar name={u.name} size={20} /> {u.name}
                </button>
              ))}
            </div>
          )}
          <div className="mt-2 flex items-center justify-between">
            <span className="hidden text-[11px] text-ink-faint sm:inline">Ctrl/⌘ + Enter to send</span>
            <button className="btn-primary btn-sm ml-auto" disabled={pending || !text.trim()} onClick={submit}>{pending && <Loader2 className="h-3.5 w-3.5 animate-spin" />} Comment</button>
          </div>
        </div>
      </div>
    </div>
  );
}
