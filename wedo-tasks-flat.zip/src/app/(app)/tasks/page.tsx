import type { Metadata } from "next";
import { can, requireUser } from "@/lib/auth";
import { listTasks, parseFilters } from "@/lib/task-queries";
import { PageHeader } from "@/components/ui/bits";
import { TasksView } from "@/components/tasks/tasks-view";
import { plural } from "@/lib/dates";

export const metadata: Metadata = { title: "All tasks" };

export default async function TasksPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const user = await requireUser();
  const filters = parseFilters(await searchParams);
  const rows = await listTasks(user, filters);
  return (
    <>
      <PageHeader
        title="All tasks"
        subtitle={can(user, "task.view_all") ? `${plural(rows.length, "task")} across the agency` : `${plural(rows.length, "task")} visible to you`}
      />
      <TasksView rows={rows} />
    </>
  );
}
