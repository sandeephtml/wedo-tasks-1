import type { Metadata } from "next";
import Link from "next/link";
import clsx from "clsx";
import { AlertTriangle, Building2, CheckCircle2, Clock, ListTodo, Loader, Users, Eye } from "lucide-react";
import { requirePagePermission } from "@/lib/auth";
import { getDashboard } from "@/lib/dashboard";
import { formatDay, timeAgo } from "@/lib/dates";
import { Avatar, AvatarStack, PageHeader } from "@/components/ui/bits";
import { PriorityBadge } from "@/components/tasks/status-pill";

export const metadata: Metadata = { title: "Dashboard" };

export default async function DashboardPage() {
  const user = await requirePagePermission("dashboard.view");
  const d = await getDashboard();
  const cards = [
    { label: "Active clients", value: d.activeClients, icon: Building2, href: "/clients?status=ACTIVE", cls: "bg-brand-soft text-brand" },
    { label: "Team members", value: d.teamMembers, icon: Users, href: "/team", cls: "bg-accent-soft text-accent" },
    { label: "Total tasks", value: d.counts.total, icon: ListTodo, href: "/tasks?completed=1", cls: "bg-page text-ink" },
    { label: "Pending", value: d.counts.pending, icon: Clock, href: "/tasks", cls: "bg-warning-soft text-warning" },
    { label: "In progress", value: d.counts.inProgress, icon: Loader, href: "/tasks?view=board", cls: "bg-brand-soft text-brand" },
    { label: "Under review", value: d.counts.review, icon: Eye, href: "/tasks?view=board", cls: "bg-brand-soft text-brand" },
    { label: "Completed", value: d.counts.completed, icon: CheckCircle2, href: "/tasks?completed=1", cls: "bg-success-soft text-success" },
    { label: "Overdue", value: d.counts.overdue, icon: AlertTriangle, href: "/tasks?due=overdue", cls: "bg-danger-soft text-danger" },
  ];
  const hour = Number(new Intl.DateTimeFormat("en-GB", { hour: "numeric", hour12: false, timeZone: process.env.APP_TIMEZONE || "Asia/Kolkata" }).format(new Date()));
  const greeting = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";

  return (
    <>
      <PageHeader title={`${greeting}, ${user.name.split(" ")[0]}`} subtitle="Here's how the agency is doing today." />

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {cards.map((c) => (
          <Link key={c.label} href={c.href} className="card flex items-center gap-3 p-4 transition-shadow hover:shadow-pop">
            <span className={clsx("flex h-10 w-10 shrink-0 items-center justify-center rounded-lg", c.cls)}><c.icon className="h-5 w-5" /></span>
            <span className="min-w-0"><span className="block font-display text-2xl font-semibold leading-none">{c.value}</span><span className="mt-1 block truncate text-xs text-ink-muted">{c.label}</span></span>
          </Link>
        ))}
      </div>

      <h2 className="mb-3 mt-7 font-display text-lg font-semibold">Departments</h2>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-5">
        {d.deptCards.map((dep) => (
          <Link key={dep.id} href={`/tasks?department=${dep.id}`} className="card p-4 hover:shadow-pop">
            <div className="flex items-center gap-2"><span className="h-2.5 w-2.5 rounded-full" style={{ background: dep.color }} /><span className="truncate text-sm font-semibold">{dep.name}</span></div>
            <div className="mt-3 flex items-end justify-between"><span className="font-display text-2xl font-semibold">{dep.pct}%</span><span className="text-xs text-ink-muted">{dep.done}/{dep.total} done</span></div>
            <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-page"><div className="h-full rounded-full" style={{ width: `${dep.pct}%`, background: dep.color }} /></div>
            {dep.overdue > 0 && <p className="mt-2 text-xs font-medium text-danger">{dep.overdue} overdue</p>}
          </Link>
        ))}
      </div>

      <div className="mt-7 grid grid-cols-1 gap-5 xl:grid-cols-[minmax(0,1fr)_380px]">
        <div className="space-y-5 min-w-0">
          <section className="card overflow-hidden">
            <h2 className="border-b border-line px-4 py-3 font-semibold">Team performance</h2>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[640px]">
                <thead className="bg-page/60"><tr>
                  <th className="table-th">Member</th><th className="table-th text-right">Open</th><th className="table-th text-right">In progress</th>
                  <th className="table-th text-right">In review</th><th className="table-th text-right">Overdue</th><th className="table-th text-right">Done (30d)</th><th className="table-th text-right">On time</th>
                </tr></thead>
                <tbody className="divide-y divide-line">
                  {d.team.map((m) => (
                    <tr key={m.id} className="hover:bg-page/50">
                      <td className="table-td"><Link href={`/tasks?assignee=${m.id}`} className="flex items-center gap-2 hover:text-brand"><Avatar name={m.name} size={28} /><span><span className="block font-medium">{m.name}</span>{m.title && <span className="block text-xs text-ink-faint">{m.title}</span>}</span></Link></td>
                      <td className="table-td text-right">{m.open}</td>
                      <td className="table-td text-right">{m.inProgress}</td>
                      <td className="table-td text-right">{m.review}</td>
                      <td className={clsx("table-td text-right", m.overdue && "font-semibold text-danger")}>{m.overdue}</td>
                      <td className="table-td text-right">{m.completed30}</td>
                      <td className="table-td text-right text-ink-muted">{m.onTimePct === null ? "—" : `${m.onTimePct}%`}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          <section className="card">
            <h2 className="border-b border-line px-4 py-3 font-semibold">Upcoming deadlines</h2>
            <div className="grid grid-cols-1 divide-y divide-line md:grid-cols-2 md:divide-x md:divide-y-0">
              {[d.deadlines.slice(0, 2), d.deadlines.slice(2)].map((col, i) => (
                <div key={i} className="divide-y divide-line">
                  {col.map((g) => (
                    <div key={g.key} className="p-4">
                      <p className="mb-2 flex items-center justify-between text-xs font-semibold uppercase tracking-wide text-ink-faint">{g.label}<span className="rounded-full bg-page px-2 py-0.5 normal-case text-ink-muted">{g.items.length}</span></p>
                      {g.items.length ? (
                        <ul className="space-y-2">
                          {g.items.slice(0, 6).map((t) => (
                            <li key={t.id}>
                              <Link href={`/tasks/${t.id}`} className="flex items-center gap-2 rounded-lg p-1.5 hover:bg-page">
                                <span className="min-w-0 flex-1"><span className="block truncate text-sm font-medium">{t.title}</span><span className="block truncate text-xs text-ink-muted">{t.client ?? "Internal"} · {formatDay(t.dueDate)}</span></span>
                                <PriorityBadge id={t.priorityId} />
                                <AvatarStack names={t.assignees} size={20} max={2} />
                              </Link>
                            </li>
                          ))}
                          {g.items.length > 6 && <li className="text-xs text-ink-muted">+{g.items.length - 6} more</li>}
                        </ul>
                      ) : <p className="text-sm text-ink-faint">Nothing due.</p>}
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </section>
        </div>

        <aside className="card h-fit">
          <h2 className="border-b border-line px-4 py-3 font-semibold">Recent activity</h2>
          <ul className="divide-y divide-line">
            {d.activity.map((a) => (
              <li key={a.id} className="flex gap-3 px-4 py-3 text-sm">
                <Avatar name={a.actor?.name ?? "System"} size={28} />
                <div className="min-w-0">
                  <p><span className="font-medium">{a.actor?.name ?? "System"}</span> <span className="text-ink-muted">{a.message}</span></p>
                  <p className="mt-0.5 text-xs text-ink-faint">{timeAgo(a.createdAt)}{a.taskId && <> · <Link href={`/tasks/${a.taskId}`} className="text-brand hover:underline">open task</Link></>}</p>
                </div>
              </li>
            ))}
            {!d.activity.length && <li className="px-4 py-10 text-center text-sm text-ink-faint">No activity yet. It appears here as your team creates and updates tasks.</li>}
          </ul>
        </aside>
      </div>
      {d.counts.total === 0 && <p className="mt-6 text-center text-sm text-ink-muted">No tasks yet. Every number above comes from the database and will fill in as your team works.</p>}
    </>
  );
}
