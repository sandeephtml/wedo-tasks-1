export default function Loading() {
  return (
    <div className="animate-pulse" aria-busy="true" aria-label="Loading">
      <div className="mb-2 h-7 w-56 rounded-lg bg-line" />
      <div className="mb-6 h-4 w-80 max-w-full rounded bg-line/70" />
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-20 rounded-card bg-line/60" />)}
      </div>
      <div className="mt-6 space-y-2">
        {Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-14 rounded-lg bg-line/50" />)}
      </div>
    </div>
  );
}
