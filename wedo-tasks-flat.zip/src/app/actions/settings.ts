"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import type { StatusCategory } from "@prisma/client";
import { prisma } from "@/lib/db";
import { ActionError, requireActionUser } from "@/lib/auth";
import { runAction } from "@/lib/action-result";
import { audit } from "@/lib/events";
import { ALL_PERMISSIONS } from "@/lib/permissions";
import { hexColor, idSchema } from "@/lib/validation";

const refresh = () => revalidatePath("/", "layout");
const REQUIRED: StatusCategory[] = ["REVIEW", "REVISION", "DONE"];
const itemSchema = z.object({ name: z.string().trim().min(1, "Name is required").max(40), color: hexColor });

function makeKey(name: string) {
  return `${name.toUpperCase().replace(/[^A-Z0-9]+/g, "_").replace(/^_|_$/g, "").slice(0, 30) || "ITEM"}_${Date.now().toString(36).toUpperCase()}`;
}

// ───── Statuses ─────
export async function saveStatus(id: string | null, raw: { name: string; color: string; category: StatusCategory }) {
  return runAction(async () => {
    const me = await requireActionUser("settings.manage");
    const d = itemSchema.extend({ category: z.enum(["OPEN", "REVIEW", "REVISION", "DONE"]) }).parse(raw);
    await prisma.$transaction(async (tx) => {
      if (id) {
        const s = await tx.taskStatus.findUnique({ where: { id: idSchema.parse(id) } });
        if (!s) throw new ActionError("Status not found.");
        if (s.isDefault && d.category !== "OPEN") throw new ActionError("The default status for new tasks must be a normal (open) status.");
        if (s.category !== d.category && REQUIRED.includes(s.category) && (await tx.taskStatus.count({ where: { category: s.category } })) <= 1) {
          throw new ActionError("This is the only status in its workflow category — add another one before changing it.");
        }
        await tx.taskStatus.update({ where: { id: s.id }, data: d });
        if (s.category !== d.category) await tx.task.updateMany({ where: { statusId: s.id }, data: { completedAt: d.category === "DONE" ? new Date() : null } });
      } else {
        const max = await tx.taskStatus.aggregate({ _max: { order: true } });
        await tx.taskStatus.create({ data: { ...d, key: makeKey(d.name), order: (max._max.order ?? 0) + 1 } });
      }
      await audit(me.id, id ? "status.update" : "status.create", "TaskStatus", id, d, tx);
    });
    refresh();
  });
}

export async function setDefaultStatus(id: string) {
  return runAction(async () => {
    const me = await requireActionUser("settings.manage");
    const s = await prisma.taskStatus.findUnique({ where: { id: idSchema.parse(id) } });
    if (!s) throw new ActionError("Status not found.");
    if (s.category !== "OPEN") throw new ActionError("Only normal (open) statuses can be the default.");
    await prisma.$transaction([
      prisma.taskStatus.updateMany({ data: { isDefault: false } }),
      prisma.taskStatus.update({ where: { id: s.id }, data: { isDefault: true } }),
      prisma.auditLog.create({ data: { actorId: me.id, action: "status.default", entityType: "TaskStatus", entityId: s.id, details: { name: s.name } } }),
    ]);
    refresh();
  });
}

export async function deleteStatus(id: string) {
  return runAction(async () => {
    const me = await requireActionUser("settings.manage");
    const s = await prisma.taskStatus.findUnique({ where: { id: idSchema.parse(id) }, include: { _count: { select: { tasks: true } } } });
    if (!s) throw new ActionError("Status not found.");
    if (s.isDefault) throw new ActionError("Choose another default status first.");
    if (s._count.tasks) throw new ActionError(`${s._count.tasks} task(s) use this status. Move them first.`);
    if (REQUIRED.includes(s.category) && (await prisma.taskStatus.count({ where: { category: s.category } })) <= 1) {
      throw new ActionError("This status is required by the review workflow.");
    }
    await prisma.taskStatus.delete({ where: { id: s.id } });
    await audit(me.id, "status.delete", "TaskStatus", s.id, { name: s.name });
    refresh();
  });
}

// ───── Priorities ─────
export async function savePriority(id: string | null, raw: { name: string; color: string }) {
  return runAction(async () => {
    const me = await requireActionUser("settings.manage");
    const d = itemSchema.parse(raw);
    if (id) await prisma.priority.update({ where: { id: idSchema.parse(id) }, data: d });
    else {
      const max = await prisma.priority.aggregate({ _max: { order: true } });
      await prisma.priority.create({ data: { ...d, key: makeKey(d.name), order: (max._max.order ?? 0) + 1 } });
    }
    await audit(me.id, id ? "priority.update" : "priority.create", "Priority", id, d);
    refresh();
  });
}

export async function setDefaultPriority(id: string) {
  return runAction(async () => {
    const me = await requireActionUser("settings.manage");
    const p = await prisma.priority.findUnique({ where: { id: idSchema.parse(id) } });
    if (!p) throw new ActionError("Priority not found.");
    await prisma.$transaction([
      prisma.priority.updateMany({ data: { isDefault: false } }),
      prisma.priority.update({ where: { id: p.id }, data: { isDefault: true } }),
      prisma.auditLog.create({ data: { actorId: me.id, action: "priority.default", entityType: "Priority", entityId: p.id, details: { name: p.name } } }),
    ]);
    refresh();
  });
}

export async function deletePriority(id: string) {
  return runAction(async () => {
    const me = await requireActionUser("settings.manage");
    const p = await prisma.priority.findUnique({ where: { id: idSchema.parse(id) }, include: { _count: { select: { tasks: true, recurring: true } } } });
    if (!p) throw new ActionError("Priority not found.");
    if (p.isDefault) throw new ActionError("Choose another default priority first.");
    if (p._count.tasks || p._count.recurring) throw new ActionError(`${p._count.tasks + p._count.recurring} task(s) or templates use this priority. Change them first.`);
    await prisma.priority.delete({ where: { id: p.id } });
    await audit(me.id, "priority.delete", "Priority", p.id, { name: p.name });
    refresh();
  });
}

/** Swap an item with its neighbour (dir -1 = up, 1 = down). */
export async function reorder(kind: "status" | "priority", id: string, dir: -1 | 1) {
  return runAction(async () => {
    await requireActionUser("settings.manage");
    z.enum(["status", "priority"]).parse(kind);
    const list = kind === "status"
      ? await prisma.taskStatus.findMany({ orderBy: { order: "asc" }, select: { id: true } })
      : await prisma.priority.findMany({ orderBy: { order: "asc" }, select: { id: true } });
    const i = list.findIndex((x) => x.id === id);
    const j = i + (dir === -1 ? -1 : 1);
    if (i < 0 || j < 0 || j >= list.length) return;
    [list[i], list[j]] = [list[j]!, list[i]!];
    await prisma.$transaction(
      list.map((x, order) => (kind === "status" ? prisma.taskStatus.update({ where: { id: x.id }, data: { order } }) : prisma.priority.update({ where: { id: x.id }, data: { order } }))),
    );
    refresh();
  });
}

// ───── Roles ─────
export async function setRolePermissions(roleId: string, keys: string[]) {
  return runAction(async () => {
    const me = await requireActionUser("settings.manage");
    const role = await prisma.role.findUnique({ where: { id: idSchema.parse(roleId) }, include: { permissions: { include: { permission: true } } } });
    if (!role) throw new ActionError("Role not found.");
    if (role.key === "SUPER_ADMIN") throw new ActionError("The Super Admin always has every permission.");
    if (me.roleKey !== "SUPER_ADMIN" && role.rank >= me.roleRank) throw new ActionError("Only the Super Admin can change permissions for your role or above.");
    const wanted = [...new Set(z.array(z.enum(ALL_PERMISSIONS as [string, ...string[]])).parse(keys))];
    const perms = await prisma.permission.findMany({ where: { key: { in: wanted } } });
    const before = role.permissions.map((p) => p.permission.key);
    await prisma.$transaction(async (tx) => {
      await tx.rolePermission.deleteMany({ where: { roleId: role.id } });
      await tx.rolePermission.createMany({ data: perms.map((p) => ({ roleId: role.id, permissionId: p.id })) });
      await audit(me.id, "role.permissions", "Role", role.id, { role: role.name, added: wanted.filter((k) => !before.includes(k)), removed: before.filter((k) => !wanted.includes(k)) }, tx);
    });
    refresh();
  });
}
