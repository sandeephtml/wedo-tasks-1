"use server";

import { z } from "zod";
import { prisma } from "@/lib/db";
import { requireActionUser } from "@/lib/auth";
import { runAction } from "@/lib/action-result";
import { timeAgo } from "@/lib/dates";

export async function listNotifications() {
  return runAction(async () => {
    const me = await requireActionUser();
    const [items, unread] = await Promise.all([
      prisma.notification.findMany({
        where: { userId: me.id },
        orderBy: { createdAt: "desc" },
        take: 20,
        include: { actor: { select: { name: true } } },
      }),
      prisma.notification.count({ where: { userId: me.id, readAt: null } }),
    ]);
    return {
      unread,
      items: items.map((n) => ({
        id: n.id, type: n.type, title: n.title, body: n.body, taskId: n.taskId,
        actor: n.actor?.name ?? null, read: !!n.readAt, ago: timeAgo(n.createdAt),
      })),
    };
  });
}

export async function unreadCount() {
  return runAction(async () => {
    const me = await requireActionUser();
    return prisma.notification.count({ where: { userId: me.id, readAt: null } });
  });
}

export async function markNotificationRead(id: string) {
  return runAction(async () => {
    const me = await requireActionUser();
    await prisma.notification.updateMany({ where: { id: z.string().parse(id), userId: me.id, readAt: null }, data: { readAt: new Date() } });
  });
}

export async function markAllNotificationsRead() {
  return runAction(async () => {
    const me = await requireActionUser();
    await prisma.notification.updateMany({ where: { userId: me.id, readAt: null }, data: { readAt: new Date() } });
  });
}
