"use server";

import { revalidatePath } from "next/cache";
import bcrypt from "bcryptjs";
import { randomBytes } from "crypto";
import { z } from "zod";
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";
import { ActionError, can, requireActionUser, type CurrentUser } from "@/lib/auth";
import { runAction } from "@/lib/action-result";
import { audit } from "@/lib/events";
import { idSchema, optionalText, passwordSchema } from "@/lib/validation";

const ADMIN_RANK = 80; // roles at or above this rank are "admin accounts"

const userSchema = z.object({
  name: z.string().trim().min(1, "Name is required").max(80),
  email: z.string().trim().toLowerCase().email("Enter a valid email").max(160),
  title: optionalText(80),
  roleId: idSchema,
  departmentIds: z.array(idSchema).max(20).default([]),
});

function tempPassword() {
  // Readable, meets policy (letters + digits), ~72 bits.
  return `${randomBytes(9).toString("base64url").replace(/[-_]/g, "x")}7`;
}

/** Throws unless `me` may manage `target` (and/or assign `role`). */
async function assertCanManage(me: CurrentUser, opts: { targetId?: string; roleId?: string }) {
  if (!can(me, "user.manage")) throw new ActionError("You don't have permission to manage team logins.");
  const manageAdmins = can(me, "user.manage_admins");
  if (opts.roleId) {
    const role = await prisma.role.findUnique({ where: { id: opts.roleId } });
    if (!role) throw new ActionError("Unknown role.");
    if (role.rank >= ADMIN_RANK && !manageAdmins) throw new ActionError("Only the Super Admin can create or promote admin accounts.");
    if (role.rank > me.roleRank) throw new ActionError("You can't assign a role above your own.");
  }
  if (opts.targetId) {
    const target = await prisma.user.findUnique({ where: { id: opts.targetId }, include: { role: true } });
    if (!target) throw new ActionError("User not found.");
    if (target.role.rank >= ADMIN_RANK && !manageAdmins && target.id !== me.id) throw new ActionError("Only the Super Admin can manage admin accounts.");
    if (target.role.rank > me.roleRank) throw new ActionError("You can't manage someone more senior than you.");
    return target;
  }
  return null;
}

async function assertNotLastSuperAdmin(userId: string) {
  const u = await prisma.user.findUnique({ where: { id: userId }, include: { role: true } });
  if (u?.role.key !== "SUPER_ADMIN") return;
  const others = await prisma.user.count({ where: { isActive: true, role: { key: "SUPER_ADMIN" }, id: { not: userId } } });
  if (!others) throw new ActionError("This is the only active Super Admin — that change would lock everyone out.");
}

function uniqueEmail(e: unknown): never {
  if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002") throw new ActionError("A user with that email already exists.");
  throw e;
}

export async function createUser(raw: z.input<typeof userSchema> & { password?: string }) {
  return runAction(async () => {
    const me = await requireActionUser("user.manage");
    const d = userSchema.parse(raw);
    await assertCanManage(me, { roleId: d.roleId });
    const password = raw.password ? passwordSchema.parse(raw.password) : tempPassword();
    const user = await prisma.$transaction(async (tx) => {
      const u = await tx.user
        .create({
          data: {
            name: d.name, email: d.email, title: d.title ?? null, roleId: d.roleId,
            passwordHash: await bcrypt.hash(password, 12), mustChangePassword: true,
            departments: { create: [...new Set(d.departmentIds)].map((departmentId) => ({ departmentId })) },
          },
        })
        .catch(uniqueEmail);
      await audit(me.id, "user.create", "User", u.id, { name: u.name, email: u.email, roleId: d.roleId, departmentIds: d.departmentIds }, tx);
      return u;
    });
    revalidatePath("/", "layout");
    return { id: user.id, tempPassword: password };
  });
}

export async function updateUser(id: string, raw: z.input<typeof userSchema>) {
  return runAction(async () => {
    const me = await requireActionUser("user.manage");
    const d = userSchema.parse(raw);
    const target = (await assertCanManage(me, { targetId: idSchema.parse(id), roleId: d.roleId }))!;
    if (target.id === me.id && target.roleId !== d.roleId) throw new ActionError("You can't change your own role.");
    if (target.roleId !== d.roleId) await assertNotLastSuperAdmin(target.id);
    await prisma.$transaction(async (tx) => {
      await tx.user
        .update({
          where: { id: target.id },
          data: {
            name: d.name, email: d.email, title: d.title ?? null, roleId: d.roleId,
            departments: { deleteMany: {}, create: [...new Set(d.departmentIds)].map((departmentId) => ({ departmentId })) },
          },
        })
        .catch(uniqueEmail);
      await audit(me.id, "user.update", "User", target.id, { before: { name: target.name, email: target.email, roleId: target.roleId }, after: d }, tx);
    });
    revalidatePath("/", "layout");
  });
}

export async function resetUserPassword(id: string, password?: string) {
  return runAction(async () => {
    const me = await requireActionUser("user.manage");
    const target = (await assertCanManage(me, { targetId: idSchema.parse(id) }))!;
    if (target.id === me.id) throw new ActionError("Use My account to change your own password.");
    const pw = password ? passwordSchema.parse(password) : tempPassword();
    await prisma.$transaction(async (tx) => {
      await tx.user.update({
        where: { id: target.id },
        data: { passwordHash: await bcrypt.hash(pw, 12), mustChangePassword: true, sessionVersion: { increment: 1 } },
      });
      await tx.loginAttempt.deleteMany({ where: { email: target.email, success: false } });
      await audit(me.id, "user.reset_password", "User", target.id, { email: target.email }, tx);
    });
    return { tempPassword: pw };
  });
}

export async function setUserActive(id: string, active: boolean) {
  return runAction(async () => {
    const me = await requireActionUser("user.manage");
    const target = (await assertCanManage(me, { targetId: idSchema.parse(id) }))!;
    if (target.id === me.id) throw new ActionError("You can't deactivate your own account.");
    if (!active) await assertNotLastSuperAdmin(target.id);
    await prisma.$transaction(async (tx) => {
      await tx.user.update({ where: { id: target.id }, data: { isActive: z.boolean().parse(active), sessionVersion: { increment: 1 } } });
      await audit(me.id, active ? "user.reactivate" : "user.deactivate", "User", target.id, { email: target.email }, tx);
    });
    revalidatePath("/", "layout");
  });
}
