"use server";

import { cookies, headers } from "next/headers";
import { redirect } from "next/navigation";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { SESSION_COOKIE, sessionCookieOptions, signSession } from "@/lib/session";
import { ActionError, requireActionUser } from "@/lib/auth";
import { runAction } from "@/lib/action-result";
import { passwordSchema } from "@/lib/validation";

const MAX_FAILED = 5;
const WINDOW_MIN = 15;
// Hash of a random string: used so unknown emails take as long as wrong passwords.
const DUMMY_HASH = "$2b$12$l6XMiXWmfIe4lF0Q0YFUV.s/Mg.n09iFKaNMDKvK9w0m9OUQbABIG";

export type LoginState = { error?: string } | undefined;

function safeNext(next: unknown) {
  return typeof next === "string" && next.startsWith("/") && !next.startsWith("//") && !next.startsWith("/login") ? next : "/";
}

export async function login(_prev: LoginState, formData: FormData): Promise<LoginState> {
  const parsed = z
    .object({ email: z.string().trim().toLowerCase().email(), password: z.string().min(1).max(200) })
    .safeParse({ email: formData.get("email"), password: formData.get("password") });
  if (!parsed.success) return { error: "Enter a valid email and password." };
  const { email, password } = parsed.data;
  const ip = (await headers()).get("x-forwarded-for")?.split(",")[0]?.trim() ?? null;

  let user: { id: string; sessionVersion: number; mustChangePassword: boolean };
  try {
    const since = new Date(Date.now() - WINDOW_MIN * 60_000);
    const failed = await prisma.loginAttempt.count({ where: { email, success: false, createdAt: { gte: since } } });
    if (failed >= MAX_FAILED) {
      return { error: `Too many failed attempts. Try again in ${WINDOW_MIN} minutes or ask an admin to reset your password.` };
    }

    const found = await prisma.user.findUnique({ where: { email } });
    const valid = await bcrypt.compare(password, found?.passwordHash ?? DUMMY_HASH);
    if (!found || !valid || !found.isActive) {
      await prisma.loginAttempt.create({ data: { email, ip, success: false } });
      return { error: found && valid && !found.isActive ? "This account has been deactivated." : "Incorrect email or password." };
    }

    await prisma.$transaction([
      prisma.loginAttempt.create({ data: { email, ip, success: true } }),
      prisma.user.update({ where: { id: found.id }, data: { lastLoginAt: new Date() } }),
    ]);
    user = found;
  } catch (e) {
    console.error("[login] database error", e);
    return { error: "The server can't reach the database right now. An admin should open /api/health to see what's wrong." };
  }

  const token = await signSession({ sub: user.id, sv: user.sessionVersion });
  (await cookies()).set(SESSION_COOKIE, token, sessionCookieOptions());
  redirect(user.mustChangePassword ? "/account?first=1" : safeNext(formData.get("next")));
}

export async function logout() {
  (await cookies()).delete(SESSION_COOKIE);
  redirect("/login");
}

export async function changeOwnPassword(input: { current: string; next: string }) {
  return runAction(async () => {
    const me = await requireActionUser();
    const data = z.object({ current: z.string().min(1, "Enter your current password"), next: passwordSchema }).parse(input);
    const user = await prisma.user.findUniqueOrThrow({ where: { id: me.id } });
    if (!(await bcrypt.compare(data.current, user.passwordHash))) throw new ActionError("Current password is incorrect.");
    if (data.current === data.next) throw new ActionError("Choose a password different from the current one.");
    const updated = await prisma.user.update({
      where: { id: me.id },
      data: { passwordHash: await bcrypt.hash(data.next, 12), mustChangePassword: false, sessionVersion: { increment: 1 } },
    });
    // Signs out other devices; re-issue this device's cookie with the new session version.
    const token = await signSession({ sub: me.id, sv: updated.sessionVersion });
    (await cookies()).set(SESSION_COOKIE, token, sessionCookieOptions());
  });
}
