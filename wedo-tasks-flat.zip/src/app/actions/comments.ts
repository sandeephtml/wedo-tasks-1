"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { ActionError, can, requireActionUser } from "@/lib/auth";
import { runAction } from "@/lib/action-result";
import { logActivity, notify } from "@/lib/events";
import { visibleTasksWhere } from "@/lib/task-access";
import { findMentionedUserIds } from "@/lib/mentions";
import { idSchema } from "@/lib/validation";

export async function addComment(taskId: string, body: string) {
  return runAction(async () => {
    const me = await requireActionUser();
    const text = z.string().trim().min(1, "Write a comment first").max(5000).parse(body);
    const task = await prisma.task.findFirst({
      where: { AND: [{ id: idSchema.parse(taskId) }, visibleTasksWhere(me)] },
      include: { assignees: { select: { userId: true } }, collaborators: { select: { userId: true } } },
    });
    if (!task) throw new ActionError("Task not found or you don't have access to it.");
    const users = await prisma.user.findMany({ where: { isActive: true }, select: { id: true, name: true } });
    const mentioned = findMentionedUserIds(text, users).filter((id) => id !== me.id);
    const watchers = [task.createdById, ...task.assignees.map((a) => a.userId), ...task.collaborators.map((c) => c.userId)].filter((id) => !mentioned.includes(id));
    const snippet = text.length > 140 ? `${text.slice(0, 140)}…` : text;

    await prisma.$transaction(async (tx) => {
      await tx.comment.create({ data: { taskId: task.id, authorId: me.id, body: text } });
      await logActivity({ type: "comment.added", message: `commented on "${task.title}"`, actorId: me.id, taskId: task.id, clientId: task.clientId }, tx);
      await notify(mentioned, { type: "MENTIONED", title: `${me.name} mentioned you on "${task.title}"`, body: snippet, taskId: task.id, actorId: me.id }, tx);
      await notify(watchers, { type: "COMMENTED", title: `${me.name} commented on "${task.title}"`, body: snippet, taskId: task.id, actorId: me.id }, tx);
    });
    revalidatePath(`/tasks/${task.id}`);
  });
}

export async function deleteComment(commentId: string) {
  return runAction(async () => {
    const me = await requireActionUser();
    const c = await prisma.comment.findUnique({ where: { id: idSchema.parse(commentId) } });
    if (!c) throw new ActionError("Comment not found.");
    if (c.authorId !== me.id && !can(me, "task.edit_any")) throw new ActionError("You can only delete your own comments.");
    await prisma.comment.delete({ where: { id: c.id } });
    revalidatePath(`/tasks/${c.taskId}`);
  });
}
