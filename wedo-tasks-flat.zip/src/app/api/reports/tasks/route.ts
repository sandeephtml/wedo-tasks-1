import { NextResponse } from "next/server";
import { can, getCurrentUser } from "@/lib/auth";
import { getReportTasks, parseReportFilters, tasksToCsv } from "@/lib/reports";
import { audit } from "@/lib/events";
import { todayStr } from "@/lib/dates";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (!can(user, "report.view")) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const filters = parseReportFilters(Object.fromEntries(new URL(req.url).searchParams));
  const tasks = await getReportTasks(user, filters);
  await audit(user.id, "report.export", "Report", null, { ...filters, rows: tasks.length });
  return new NextResponse(tasksToCsv(tasks), {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="wedo-tasks-${todayStr()}.csv"`,
      "Cache-Control": "no-store",
    },
  });
}
