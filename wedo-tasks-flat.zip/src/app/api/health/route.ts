import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";

export const dynamic = "force-dynamic";

/**
 * Deployment self-check. Reports which settings are missing and whether the database is reachable
 * and set up. Never returns secret values.
 */
export async function GET() {
  const env = {
    DATABASE_URL: !!process.env.DATABASE_URL,
    DIRECT_URL: !!process.env.DIRECT_URL,
    AUTH_SECRET: (process.env.AUTH_SECRET?.length ?? 0) >= 32,
    CRON_SECRET: !!process.env.CRON_SECRET,
  };
  const problems: string[] = [];
  if (!env.DATABASE_URL) problems.push("DATABASE_URL is not set.");
  if (!env.AUTH_SECRET) problems.push("AUTH_SECRET is missing or shorter than 32 characters.");
  if (!env.CRON_SECRET) problems.push("CRON_SECRET is not set (only the daily job needs it).");

  let database: "ok" | "unreachable" | "not set up" | "no users" = "unreachable";
  if (env.DATABASE_URL) {
    try {
      const users = await prisma.user.count();
      database = users > 0 ? "ok" : "no users";
      if (!users) problems.push("Database has no users: run the seed (npm run db:seed).");
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      if (/does not exist/i.test(msg)) {
        database = "not set up";
        problems.push("Tables are missing: run `npx prisma migrate deploy` and `npm run db:seed`.");
      } else if (/Query Engine|binaryTargets|libquery_engine/i.test(msg)) {
        problems.push("Prisma engine not found for this server (redeploy with the latest code).");
      } else {
        problems.push("Can't connect to the database: check DATABASE_URL (password, host, sslmode=require).");
      }
      console.error("[health]", msg);
    }
  }
  const ok = problems.filter((p) => !p.startsWith("CRON_SECRET")).length === 0;
  return NextResponse.json({ ok, env, database, problems }, { status: ok ? 200 : 503, headers: { "Cache-Control": "no-store" } });
}
