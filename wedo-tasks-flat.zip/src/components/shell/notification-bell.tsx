"use client";

import { useEffect, useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import clsx from "clsx";
import { Bell, CheckCheck, Loader2, AtSign, MessageSquare, Send, CheckCircle2, RotateCcw, AlarmClock, UserPlus } from "lucide-react";
import { listNotifications, markAllNotificationsRead, markNotificationRead, unreadCount } from "@/app/actions/notifications";

type Item = { id: string; type: string; title: string; body: string | null; taskId: string | null; actor: string | null; read: boolean; ago: string };

const ICONS: Record<string, typeof Bell> = {
  ASSIGNED: UserPlus, MENTIONED: AtSign, COMMENTED: MessageSquare, SUBMITTED: Send,
  APPROVED: CheckCircle2, REVISION: RotateCcw, OVERDUE: AlarmClock,
};

export function NotificationBell({ initialUnread }: { initialUnread: number }) {
  const [open, setOpen] = useState(false);
  const [count, setCount] = useState(initialUnread);
  const [items, setItems] = useState<Item[] | null>(null);
  const [loading, startLoading] = useTransition();
  const ref = useRef<HTMLDivElement>(null);
  const router = useRouter();

  useEffect(() => setCount(initialUnread), [initialUnread]);
  useEffect(() => {
    const t = setInterval(async () => {
      if (document.visibilityState !== "visible") return;
      const r = await unreadCount();
      if (r.ok && typeof r.data === "number") setCount(r.data);
    }, 60_000);
    return () => clearInterval(t);
  }, []);
  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => ref.current && !ref.current.contains(e.target as Node) && setOpen(false);
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [open]);

  const load = () =>
    startLoading(async () => {
      const r = await listNotifications();
      if (r.ok && r.data) {
        setItems(r.data.items);
        setCount(r.data.unread);
      }
    });

  return (
    <div className="relative" ref={ref}>
      <button
        aria-label={`Notifications${count ? ` (${count} unread)` : ""}`}
        onClick={() => { setOpen((o) => !o); if (!open) load(); }}
        className="relative rounded-lg p-2 text-ink-muted hover:bg-page hover:text-ink"
      >
        <Bell className="h-5 w-5" />
        {count > 0 && (
          <span className="absolute right-1 top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-danger px-1 text-[10px] font-bold text-white">
            {count > 99 ? "99+" : count}
          </span>
        )}
      </button>
      {open && (
        <div className="fixed inset-x-2 top-16 z-50 rounded-xl border border-line bg-surface shadow-pop sm:absolute sm:inset-x-auto sm:right-0 sm:top-11 sm:w-96">
          <div className="flex items-center justify-between border-b border-line px-4 py-3">
            <p className="text-sm font-semibold">Notifications</p>
            <button
              className="flex items-center gap-1 text-xs font-medium text-brand hover:underline disabled:opacity-40"
              disabled={!count}
              onClick={async () => {
                await markAllNotificationsRead();
                setCount(0);
                setItems((it) => it?.map((i) => ({ ...i, read: true })) ?? null);
              }}
            >
              <CheckCheck className="h-3.5 w-3.5" /> Mark all read
            </button>
          </div>
          <div className="max-h-[60vh] overflow-y-auto">
            {loading && !items && <div className="flex justify-center py-8"><Loader2 className="h-5 w-5 animate-spin text-ink-faint" /></div>}
            {items?.length === 0 && <p className="px-4 py-10 text-center text-sm text-ink-muted">You&apos;re all caught up.</p>}
            {items?.map((n) => {
              const Icon = ICONS[n.type] ?? Bell;
              return (
                <button
                  key={n.id}
                  onClick={async () => {
                    if (!n.read) {
                      await markNotificationRead(n.id);
                      setCount((c) => Math.max(0, c - 1));
                    }
                    setOpen(false);
                    if (n.taskId) router.push(`/tasks/${n.taskId}`);
                  }}
                  className={clsx("flex w-full gap-3 border-b border-line/60 px-4 py-3 text-left last:border-0 hover:bg-page", !n.read && "bg-brand-soft/50")}
                >
                  <span className={clsx("mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full", n.type === "OVERDUE" || n.type === "REVISION" ? "bg-danger-soft text-danger" : "bg-brand-soft text-brand")}>
                    <Icon className="h-3.5 w-3.5" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-sm">{n.title}</span>
                    {n.body && <span className="mt-0.5 block truncate text-xs text-ink-muted">{n.body}</span>}
                    <span className="mt-0.5 block text-[11px] text-ink-faint">{n.ago}</span>
                  </span>
                  {!n.read && <span className="mt-2 h-2 w-2 shrink-0 rounded-full bg-brand" />}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
