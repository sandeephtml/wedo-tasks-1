"use client";

import Link from "next/link";
import { useRef, useState, useEffect } from "react";
import { Menu, Search, LogOut, KeyRound, ChevronDown } from "lucide-react";
import { logout } from "@/app/actions/auth";
import { Avatar } from "@/components/ui/bits";
import { useApp } from "@/components/app-context";
import { NotificationBell } from "./notification-bell";
import { CreateTaskButton } from "@/components/tasks/create-task-button";

export function Topbar({ onMenu, unread }: { onMenu: () => void; unread: number }) {
  const { me, can } = useApp();
  const [menu, setMenu] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!menu) return;
    const onDown = (e: MouseEvent) => ref.current && !ref.current.contains(e.target as Node) && setMenu(false);
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [menu]);

  return (
    <header className="sticky top-0 z-20 flex h-16 items-center gap-2 border-b border-line bg-surface/90 px-4 backdrop-blur sm:gap-3 sm:px-6 lg:px-8">
      <button onClick={onMenu} aria-label="Open menu" className="-ml-1 rounded-lg p-2 text-ink-muted hover:bg-page lg:hidden"><Menu className="h-5 w-5" /></button>
      <form action="/tasks" className="relative max-w-md flex-1">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-faint" />
        <input name="q" type="search" placeholder="Search tasks…" aria-label="Search tasks" className="input h-9 rounded-full bg-page pl-9" />
      </form>
      <div className="ml-auto flex items-center gap-1 sm:gap-2">
        {can("task.create") && <CreateTaskButton compact />}
        <NotificationBell initialUnread={unread} />
        <div className="relative" ref={ref}>
          <button onClick={() => setMenu((m) => !m)} className="flex items-center gap-2 rounded-lg p-1 hover:bg-page" aria-label="Account menu">
            <Avatar name={me.name} size={32} />
            <ChevronDown className="hidden h-4 w-4 text-ink-faint sm:block" />
          </button>
          {menu && (
            <div className="absolute right-0 top-11 z-50 w-56 rounded-xl border border-line bg-surface py-1 shadow-pop">
              <div className="border-b border-line px-4 py-3">
                <p className="truncate text-sm font-medium">{me.name}</p>
                <p className="truncate text-xs text-ink-muted">{me.email}</p>
              </div>
              <Link href="/account" onClick={() => setMenu(false)} className="flex items-center gap-2 px-4 py-2 text-sm hover:bg-page"><KeyRound className="h-4 w-4 text-ink-faint" /> Change password</Link>
              <form action={logout}>
                <button className="flex w-full items-center gap-2 px-4 py-2 text-sm text-danger hover:bg-page"><LogOut className="h-4 w-4" /> Sign out</button>
              </form>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
