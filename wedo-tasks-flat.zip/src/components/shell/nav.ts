import { BarChart3, Building2, CheckSquare, FileBarChart, LayoutDashboard, ListTodo, Repeat, Settings, Users, Network } from "lucide-react";
import type { PermissionKey } from "@/lib/permissions";

export const NAV: { href: string; label: string; icon: typeof BarChart3; perm?: PermissionKey; section?: string }[] = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard, perm: "dashboard.view" },
  { href: "/my-tasks", label: "My Tasks", icon: CheckSquare },
  { href: "/tasks", label: "All Tasks", icon: ListTodo },
  { href: "/clients", label: "Clients", icon: Building2, section: "Workspace" },
  { href: "/team", label: "Team", icon: Users, perm: "team.view" },
  { href: "/departments", label: "Departments", icon: Network },
  { href: "/recurring", label: "Recurring", icon: Repeat, perm: "recurring.manage" },
  { href: "/reports", label: "Reports", icon: FileBarChart, perm: "report.view", section: "Admin" },
  { href: "/settings", label: "Settings", icon: Settings, perm: "settings.manage" },
];
