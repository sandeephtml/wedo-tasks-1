import clsx from "clsx";

const AVATAR_COLORS = ["#6366F1", "#EC4899", "#10B981", "#F59E0B", "#0EA5E9", "#8B5CF6", "#EF4444", "#14B8A6"];

export function initials(name: string) {
  return name.split(/\s+/).filter(Boolean).slice(0, 2).map((p) => p[0]!.toUpperCase()).join("");
}

export function Avatar({ name, size = 28, className }: { name: string; size?: number; className?: string }) {
  let h = 0;
  for (const c of name) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  return (
    <span
      title={name}
      className={clsx("inline-flex shrink-0 select-none items-center justify-center rounded-full font-semibold text-white ring-2 ring-surface", className)}
      style={{ width: size, height: size, fontSize: size * 0.4, background: AVATAR_COLORS[h % AVATAR_COLORS.length] }}
    >
      {initials(name)}
    </span>
  );
}

export function AvatarStack({ names, max = 3, size = 24 }: { names: string[]; max?: number; size?: number }) {
  if (!names.length) return <span className="text-xs text-ink-faint">Unassigned</span>;
  return (
    <span className="flex -space-x-1.5">
      {names.slice(0, max).map((n) => <Avatar key={n} name={n} size={size} />)}
      {names.length > max && (
        <span className="inline-flex items-center justify-center rounded-full bg-page text-[10px] font-semibold text-ink-muted ring-2 ring-surface" style={{ width: size, height: size }}>
          +{names.length - max}
        </span>
      )}
    </span>
  );
}

export function ColorBadge({ color, children, className }: { color: string; children: React.ReactNode; className?: string }) {
  return (
    <span className={clsx("badge", className)} style={{ background: `${color}1F`, color }}>
      <span className="h-1.5 w-1.5 rounded-full" style={{ background: color }} />
      {children}
    </span>
  );
}

const CLIENT_STATUS: Record<string, { label: string; cls: string }> = {
  ACTIVE: { label: "Active", cls: "bg-success-soft text-success" },
  ON_HOLD: { label: "On hold", cls: "bg-warning-soft text-warning" },
  UPCOMING: { label: "Upcoming", cls: "bg-brand-soft text-brand" },
};
export function ClientStatusBadge({ status }: { status: string }) {
  const s = CLIENT_STATUS[status] ?? { label: status, cls: "bg-page text-ink-muted" };
  return <span className={clsx("badge", s.cls)}>{s.label}</span>;
}

export function EmptyState({ icon, title, children }: { icon?: React.ReactNode; title: string; children?: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center px-6 py-14 text-center">
      {icon && <div className="mb-3 text-ink-faint">{icon}</div>}
      <p className="font-medium">{title}</p>
      {children && <div className="mt-1 text-sm text-ink-muted">{children}</div>}
    </div>
  );
}

export function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: React.ReactNode; actions?: React.ReactNode }) {
  return (
    <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h1 className="font-display text-xl font-semibold tracking-tight sm:text-2xl">{title}</h1>
        {subtitle && <p className="mt-0.5 text-sm text-ink-muted">{subtitle}</p>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}

export function Logo({ dark = false }: { dark?: boolean }) {
  return (
    <span className="flex items-center gap-2">
      <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand font-display text-sm font-bold text-brand-fg">
        W<span className="text-accent">.</span>
      </span>
      <span className="leading-tight">
        <span className={clsx("block font-display text-[15px] font-bold", dark ? "text-sidebar-fg" : "text-ink")}>WeDo Tasks</span>
        <span className={clsx("block text-[11px]", dark ? "text-sidebar-muted" : "text-ink-faint")}>We Do Marketing</span>
      </span>
    </span>
  );
}
