"use client";

import { useApp } from "@/components/app-context";
import { ColorBadge } from "@/components/ui/bits";

export function StatusSelect({ value, onChange, disabled, label = "Status" }: { value: string; onChange: (id: string) => void; disabled?: boolean; label?: string }) {
  const { lookups } = useApp();
  const s = lookups.statuses.find((x) => x.id === value);
  return (
    <select
      aria-label={label}
      value={value}
      disabled={disabled}
      onChange={(e) => onChange(e.target.value)}
      className="max-w-full cursor-pointer appearance-none rounded-full border-0 py-1 pl-2.5 pr-6 text-xs font-medium focus:ring-2 focus:ring-brand/30 disabled:cursor-default"
      style={{
        background: `${s?.color ?? "#999"}1F url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='10' viewBox='0 0 24 24' fill='none' stroke='%236b7280' stroke-width='3'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E") no-repeat right 8px center`,
        color: s?.color,
      }}
    >
      {lookups.statuses.map((st) => <option key={st.id} value={st.id} style={{ color: "#111" }}>{st.name}</option>)}
    </select>
  );
}

export function PriorityBadge({ id }: { id: string }) {
  const { lookups } = useApp();
  const p = lookups.priorities.find((x) => x.id === id);
  return p ? <ColorBadge color={p.color}>{p.name}</ColorBadge> : null;
}

export function StatusBadge({ id }: { id: string }) {
  const { lookups } = useApp();
  const s = lookups.statuses.find((x) => x.id === id);
  return s ? <ColorBadge color={s.color}>{s.name}</ColorBadge> : null;
}
