"use client";

import { useCallback, useState } from "react";
import { useApp } from "@/components/app-context";
import { useToast } from "@/components/ui/toast";
import { moveTask } from "@/app/actions/tasks";
import { CommentDialog } from "./revision-dialog";
import type { TaskRow } from "@/lib/task-queries";

type Pending = { taskId: string; statusId: string; position: number; prev: TaskRow[] } | null;

/**
 * Optimistic status/position changes shared by the list and board views.
 * Moving into a "revision" status first asks for the mandatory comment; failures roll back.
 */
export function useStatusChange(rows: TaskRow[], setRows: React.Dispatch<React.SetStateAction<TaskRow[]>>) {
  const { lookups, can } = useApp();
  const toast = useToast();
  const [pending, setPending] = useState<Pending>(null);

  const commit = useCallback(
    async (taskId: string, statusId: string, position: number, prev: TaskRow[], comment?: string) => {
      setRows((rs) => rs.map((r) => (r.id === taskId ? { ...r, statusId, position } : r)));
      const res = await moveTask(taskId, statusId, position, comment ?? null).catch(
        () => ({ ok: false as const, error: "Couldn't reach the server. Your change was undone — please try again." }),
      );
      if (!res.ok) {
        setRows(prev);
        toast.error(res.error);
      } else {
        const s = lookups.statuses.find((x) => x.id === statusId);
        const before = prev.find((r) => r.id === taskId);
        if (before && before.statusId !== statusId) toast.success(`Moved to ${s?.name ?? "new status"}`);
      }
    },
    [setRows, toast, lookups.statuses],
  );

  const change = useCallback(
    (taskId: string, statusId: string, position?: number, snapshot?: TaskRow[]) => {
      const prev = snapshot ?? rows;
      const task = prev.find((r) => r.id === taskId);
      if (!task) return;
      const to = lookups.statuses.find((s) => s.id === statusId);
      const from = lookups.statuses.find((s) => s.id === task.statusId);
      // Fail fast on the client for obvious permission problems (server re-checks everything).
      if (to?.category === "DONE" && !can("task.approve")) {
        toast.error("Submit the task for review — a manager will approve it.");
        if (snapshot) setRows(snapshot);
        return;
      }
      if (from?.category === "REVIEW" && task.statusId !== statusId && !can("task.approve")) {
        toast.error("This task is waiting for review. Only a manager can move it now.");
        if (snapshot) setRows(snapshot);
        return;
      }
      const pos = position ?? Math.max(0, ...prev.filter((r) => r.statusId === statusId).map((r) => r.position)) + 1024;
      if (to?.category === "REVISION" && task.statusId !== statusId) {
        setPending({ taskId, statusId, position: pos, prev });
        return;
      }
      void commit(taskId, statusId, pos, prev);
    },
    [rows, lookups.statuses, can, toast, commit, setRows],
  );

  const dialog = (
    <CommentDialog
      open={!!pending}
      title="Request revisions"
      required
      confirmLabel="Send back"
      onCancel={() => { if (pending) setRows(pending.prev); setPending(null); }}
      onConfirm={(c) => {
        if (pending) void commit(pending.taskId, pending.statusId, pending.position, pending.prev, c);
        setPending(null);
      }}
    />
  );
  return { change, dialog };
}
