"use client";

import { useState } from "react";
import { Plus } from "lucide-react";
import { TaskFormModal, type TaskFormValues } from "./task-form";

export function CreateTaskButton({ compact, initial, label = "Create task" }: { compact?: boolean; initial?: Partial<TaskFormValues>; label?: string }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button onClick={() => setOpen(true)} className="btn-primary" aria-label={label}>
        <Plus className="h-4 w-4" />
        <span className={compact ? "hidden sm:inline" : ""}>{label}</span>
      </button>
      {open && <TaskFormModal open={open} onClose={() => setOpen(false)} initial={initial} />}
    </>
  );
}
