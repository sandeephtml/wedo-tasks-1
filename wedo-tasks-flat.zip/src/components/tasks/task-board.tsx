"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import clsx from "clsx";
import {
  DndContext, DragOverlay, KeyboardSensor, PointerSensor, TouchSensor, closestCorners, pointerWithin, useDroppable, useSensor, useSensors,
  type CollisionDetection, type DragEndEvent, type DragStartEvent,
} from "@dnd-kit/core";
import { SortableContext, sortableKeyboardCoordinates, useSortable, verticalListSortingStrategy } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { Calendar, CheckSquare, MessageSquare } from "lucide-react";
import { useApp } from "@/components/app-context";
import { AvatarStack } from "@/components/ui/bits";
import { formatDay, isOverdue, todayDate } from "@/lib/dates";
import type { TaskRow } from "@/lib/task-queries";
import { PriorityBadge } from "./status-pill";
import { useStatusChange } from "./use-status-change";

const COL = "col:";

// Whatever is under the pointer wins (a card over its column); fall back to closest corners
// for keyboard dragging or when the pointer is between columns.
const collision: CollisionDetection = (args) => {
  const hits = pointerWithin(args);
  if (hits.length) {
    const cards = hits.filter((h) => !String(h.id).startsWith(COL));
    return cards.length ? cards : hits;
  }
  return closestCorners(args);
};

function Card({ task, overlay }: { task: TaskRow; overlay?: boolean }) {
  const { lookups } = useApp();
  const done = lookups.statuses.find((s) => s.id === task.statusId)?.category === "DONE";
  const overdue = isOverdue(task.dueDate, done, todayDate());
  const client = lookups.clients.find((c) => c.id === task.clientId)?.name;
  const names = task.assigneeIds.map((id) => lookups.users.find((u) => u.id === id)?.name).filter(Boolean) as string[];
  return (
    <div className={clsx("rounded-lg border border-line bg-surface p-3 shadow-card", overlay && "rotate-2 shadow-pop", overdue && "border-l-4 border-l-danger")}>
      <div className="mb-1.5 flex items-start justify-between gap-2">
        <span className="text-[11px] font-medium text-ink-faint">{client ?? "Internal"}</span>
        <PriorityBadge id={task.priorityId} />
      </div>
      <Link href={`/tasks/${task.id}`} className={clsx("block text-sm font-medium leading-snug hover:text-brand", done && "text-ink-muted line-through")} onPointerDown={(e) => e.stopPropagation()}>
        {task.title}
      </Link>
      <div className="mt-3 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2.5 text-[11px] text-ink-muted">
          {task.dueDate && <span className={clsx("flex items-center gap-1", overdue && "font-semibold text-danger")}><Calendar className="h-3 w-3" />{formatDay(task.dueDate)}</span>}
          {task.checklistTotal > 0 && <span className="flex items-center gap-1"><CheckSquare className="h-3 w-3" />{task.checklistDone}/{task.checklistTotal}</span>}
          {task.commentCount > 0 && <span className="flex items-center gap-1"><MessageSquare className="h-3 w-3" />{task.commentCount}</span>}
        </div>
        <AvatarStack names={names} size={22} />
      </div>
    </div>
  );
}

function SortableCard({ task }: { task: TaskRow }) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: task.id });
  return (
    <div
      ref={setNodeRef}
      style={{ transform: CSS.Transform.toString(transform), transition }}
      className={clsx("touch-manipulation", isDragging && "opacity-40")}
      data-task-id={task.id}
      {...attributes}
      {...listeners}
    >
      <Card task={task} />
    </div>
  );
}

function Column({ status, tasks, hint }: { status: { id: string; name: string; color: string }; tasks: TaskRow[]; hint?: string }) {
  const { setNodeRef, isOver } = useDroppable({ id: COL + status.id });
  return (
    <div className="flex w-[280px] shrink-0 flex-col rounded-xl bg-line/40" data-column={status.name}>
      <div className="flex items-center gap-2 px-3 py-2.5">
        <span className="h-2.5 w-2.5 rounded-full" style={{ background: status.color }} />
        <span className="text-sm font-semibold">{status.name}</span>
        <span className="ml-auto rounded-full bg-surface px-2 py-0.5 text-xs text-ink-muted">{tasks.length}</span>
      </div>
      <div ref={setNodeRef} className={clsx("flex min-h-[120px] flex-1 flex-col gap-2 rounded-b-xl p-2 transition-colors", isOver && "bg-brand/10")}>
        <SortableContext items={tasks.map((t) => t.id)} strategy={verticalListSortingStrategy}>
          {tasks.map((t) => <SortableCard key={t.id} task={t} />)}
        </SortableContext>
        {!tasks.length && <p className="py-6 text-center text-xs text-ink-faint">{hint ?? "Drop tasks here"}</p>}
      </div>
    </div>
  );
}

export function TaskBoard({ rows, setRows, showCompleted }: { rows: TaskRow[]; setRows: React.Dispatch<React.SetStateAction<TaskRow[]>>; showCompleted: boolean }) {
  const { lookups } = useApp();
  const { change, dialog } = useStatusChange(rows, setRows);
  const [activeId, setActiveId] = useState<string | null>(null);
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 6 } }),
    useSensor(TouchSensor, { activationConstraint: { delay: 180, tolerance: 6 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );
  const columns = useMemo(
    () => lookups.statuses.map((s) => ({ status: s, tasks: rows.filter((r) => r.statusId === s.id).sort((a, b) => a.position - b.position) })),
    [rows, lookups.statuses],
  );
  const active = rows.find((r) => r.id === activeId);

  const onDragStart = (e: DragStartEvent) => setActiveId(String(e.active.id));
  const onDragEnd = (e: DragEndEvent) => {
    setActiveId(null);
    const { active: a, over } = e;
    if (!over) return;
    const task = rows.find((r) => r.id === a.id);
    if (!task) return;
    const overId = String(over.id);
    const targetStatus = overId.startsWith(COL) ? overId.slice(COL.length) : rows.find((r) => r.id === overId)?.statusId;
    if (!targetStatus) return;
    const col = (columns.find((c) => c.status.id === targetStatus)?.tasks ?? []).filter((t) => t.id !== task.id);
    let index = col.length;
    if (!overId.startsWith(COL)) {
      const overIdx = col.findIndex((t) => t.id === overId);
      if (overIdx >= 0) {
        const sameCol = task.statusId === targetStatus;
        const fromIdx = columns.find((c) => c.status.id === targetStatus)?.tasks.findIndex((t) => t.id === task.id) ?? -1;
        const origOverIdx = columns.find((c) => c.status.id === targetStatus)?.tasks.findIndex((t) => t.id === overId) ?? -1;
        index = sameCol && fromIdx < origOverIdx ? overIdx + 1 : overIdx;
      }
    }
    const before = col[index - 1]?.position;
    const after = col[index]?.position;
    const position = before !== undefined && after !== undefined ? (before + after) / 2 : before !== undefined ? before + 1024 : after !== undefined ? after - 1024 : 1024;
    if (targetStatus === task.statusId && position === task.position) return;
    change(task.id, targetStatus, position, rows);
  };

  return (
    <>
      {dialog}
      <DndContext sensors={sensors} collisionDetection={collision} onDragStart={onDragStart} onDragEnd={onDragEnd} onDragCancel={() => setActiveId(null)}>
        <div className="-mx-4 flex gap-3 overflow-x-auto px-4 pb-4 sm:-mx-6 sm:px-6 lg:-mx-8 lg:px-8">
          {columns.map(({ status, tasks }) => (
            <Column key={status.id} status={status} tasks={tasks} hint={status.category === "DONE" && !showCompleted ? "Completed tasks are hidden — turn on “Show completed”" : undefined} />
          ))}
        </div>
        <DragOverlay>{active ? <Card task={active} overlay /> : null}</DragOverlay>
      </DndContext>
    </>
  );
}
