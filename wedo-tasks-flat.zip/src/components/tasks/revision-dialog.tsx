"use client";

import { useState } from "react";
import { Modal } from "@/components/ui/modal";

/** Asks for the comment required when sending a task back for revision (or optional approval note). */
export function CommentDialog({
  open, title, required, confirmLabel, onCancel, onConfirm,
}: { open: boolean; title: string; required: boolean; confirmLabel: string; onCancel: () => void; onConfirm: (comment: string) => void }) {
  const [text, setText] = useState("");
  return (
    <Modal
      open={open}
      onClose={() => { setText(""); onCancel(); }}
      title={title}
      size="sm"
      footer={
        <>
          <button className="btn-secondary" onClick={() => { setText(""); onCancel(); }}>Cancel</button>
          <button className="btn-primary" disabled={required && !text.trim()} onClick={() => { const t = text; setText(""); onConfirm(t); }}>{confirmLabel}</button>
        </>
      }
    >
      <label className="label" htmlFor="wf-comment">{required ? "What needs to change? (required)" : "Comment (optional)"}</label>
      <textarea id="wf-comment" rows={4} className="input" value={text} onChange={(e) => setText(e.target.value)} placeholder={required ? "Be specific so the assignee can fix it quickly…" : ""} />
    </Modal>
  );
}
