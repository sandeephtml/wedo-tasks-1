"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import clsx from "clsx";
import { Loader2, Pencil, Plus } from "lucide-react";
import { Modal } from "@/components/ui/modal";
import { useToast } from "@/components/ui/toast";
import { createClient, updateClient } from "@/app/actions/clients";
import { SERVICES } from "@/lib/validation";

type Values = { name: string; website: string; status: "ACTIVE" | "ON_HOLD" | "UPCOMING"; services: string[]; notes: string };

export function ClientFormButton({ client }: { client?: { id: string } & Values }) {
  const [open, setOpen] = useState(false);
  const [v, setV] = useState<Values>(client ?? { name: "", website: "", status: "ACTIVE", services: [], notes: "" });
  const [custom, setCustom] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();
  const toast = useToast();
  const router = useRouter();
  const allServices = [...new Set([...SERVICES, ...v.services])];
  const toggle = (s: string) => setV((x) => ({ ...x, services: x.services.includes(s) ? x.services.filter((y) => y !== s) : [...x.services, s] }));

  const save = () => {
    setError(null);
    start(async () => {
      const r = client ? await updateClient(client.id, v) : await createClient(v);
      if (!r.ok) return setError(r.error);
      toast.success(client ? "Client updated" : "Client added");
      setOpen(false);
      if (!client) setV({ name: "", website: "", status: "ACTIVE", services: [], notes: "" });
      router.refresh();
    });
  };

  return (
    <>
      {client ? (
        <button className="btn-secondary btn-sm" onClick={() => setOpen(true)}><Pencil className="h-3.5 w-3.5" /> Edit client</button>
      ) : (
        <button className="btn-primary" onClick={() => setOpen(true)}><Plus className="h-4 w-4" /> Add client</button>
      )}
      <Modal open={open} onClose={() => setOpen(false)} title={client ? `Edit ${client.name}` : "Add client"}
        footer={<><button className="btn-secondary" onClick={() => setOpen(false)}>Cancel</button><button className="btn-primary" disabled={pending || !v.name.trim()} onClick={save}>{pending && <Loader2 className="h-4 w-4 animate-spin" />} Save</button></>}>
        <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); save(); }}>
          <div><label className="label" htmlFor="c-name">Name *</label><input id="c-name" className="input" value={v.name} onChange={(e) => setV({ ...v, name: e.target.value })} maxLength={120} /></div>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div><label className="label" htmlFor="c-web">Website</label><input id="c-web" className="input" placeholder="example.com" value={v.website} onChange={(e) => setV({ ...v, website: e.target.value })} /></div>
            <div><label className="label" htmlFor="c-status">Status</label>
              <select id="c-status" className="input" value={v.status} onChange={(e) => setV({ ...v, status: e.target.value as Values["status"] })}>
                <option value="ACTIVE">Active</option><option value="ON_HOLD">On hold</option><option value="UPCOMING">Upcoming</option>
              </select></div>
          </div>
          <div>
            <span className="label">Services</span>
            <div className="flex flex-wrap gap-1.5">
              {allServices.map((s) => (
                <button type="button" key={s} onClick={() => toggle(s)} className={clsx("rounded-full border px-2.5 py-1 text-xs font-medium", v.services.includes(s) ? "border-brand bg-brand text-brand-fg" : "border-line text-ink-muted hover:border-brand/50")}>{s}</button>
              ))}
            </div>
            <div className="mt-2 flex gap-2">
              <input className="input h-8 text-xs" placeholder="Other service…" value={custom} onChange={(e) => setCustom(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); if (custom.trim()) { toggle(custom.trim()); setCustom(""); } } }} />
              <button type="button" className="btn-secondary btn-sm" onClick={() => { if (custom.trim()) { toggle(custom.trim()); setCustom(""); } }}>Add</button>
            </div>
          </div>
          <div><label className="label" htmlFor="c-notes">Notes</label><textarea id="c-notes" rows={4} className="input" value={v.notes} onChange={(e) => setV({ ...v, notes: e.target.value })} placeholder="Contacts, access, goals, reporting cadence…" /></div>
          {error && <p role="alert" className="rounded-lg bg-danger-soft px-3 py-2 text-sm text-danger">{error}</p>}
          <button type="submit" className="hidden" />
        </form>
      </Modal>
    </>
  );
}
