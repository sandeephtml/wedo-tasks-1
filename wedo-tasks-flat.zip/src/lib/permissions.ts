// Catalogue of permission keys. The *assignment* of permissions to roles lives in the
// database (RolePermission) and is editable from Settings → Roles. The defaults below are
// only used by the seed script.

export const PERMISSIONS = {
  "dashboard.view": { label: "View founders' dashboard", group: "Dashboard" },
  "task.view_all": { label: "See every task (not just own/department)", group: "Tasks" },
  "task.create": { label: "Create tasks", group: "Tasks" },
  "task.edit_any": { label: "Edit any visible task", group: "Tasks" },
  "task.assign": { label: "Change task assignees", group: "Tasks" },
  "task.approve": { label: "Approve tasks / request revisions", group: "Tasks" },
  "task.delete": { label: "Delete tasks", group: "Tasks" },
  "recurring.manage": { label: "Manage recurring tasks", group: "Tasks" },
  "client.manage": { label: "Add and edit clients", group: "Clients" },
  "team.view": { label: "View team directory", group: "Team" },
  "user.manage": { label: "Create / edit / deactivate team logins", group: "Team" },
  "user.manage_admins": { label: "Create and manage admin accounts", group: "Team" },
  "department.manage": { label: "Manage departments", group: "Team" },
  "report.view": { label: "View reports and export CSV", group: "Reports" },
  "settings.manage": { label: "Edit statuses, priorities and role permissions", group: "Settings" },
  "audit.view": { label: "View audit log", group: "Settings" },
} as const;

export type PermissionKey = keyof typeof PERMISSIONS;
export const ALL_PERMISSIONS = Object.keys(PERMISSIONS) as PermissionKey[];

export const ROLE_KEYS = ["SUPER_ADMIN", "ADMIN", "MANAGER", "MEMBER"] as const;
export type RoleKey = (typeof ROLE_KEYS)[number];

export const DEFAULT_ROLES: Record<RoleKey, { name: string; rank: number; description: string; permissions: PermissionKey[] }> = {
  SUPER_ADMIN: {
    name: "Super Admin",
    rank: 100,
    description: "Founder. Full access, including admin accounts.",
    permissions: ALL_PERMISSIONS,
  },
  ADMIN: {
    name: "Admin",
    rank: 80,
    description: "Co-founder / operations. Full access except managing admin accounts.",
    permissions: ALL_PERMISSIONS.filter((p) => p !== "user.manage_admins"),
  },
  MANAGER: {
    name: "Department Manager",
    rank: 50,
    description: "Runs one or more departments; approves work in those departments.",
    permissions: ["task.create", "task.edit_any", "task.assign", "task.approve", "recurring.manage", "team.view", "report.view"],
  },
  MEMBER: {
    name: "Team Member",
    rank: 10,
    description: "Sees tasks assigned to them or in their departments.",
    permissions: ["task.create", "team.view"],
  },
};
