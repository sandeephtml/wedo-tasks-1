// Maps editable statuses to the fixed reporting buckets used on the dashboard, client pages and reports.
export type Bucket = "pending" | "in_progress" | "on_hold" | "done";

export function bucketOf(s: { key: string; category: string }): Bucket {
  if (s.category === "DONE") return "done";
  if (s.key === "ON_HOLD") return "on_hold";
  if (s.key === "PENDING" || s.key === "BACKLOG") return "pending";
  return "in_progress"; // In Progress, Under Review, Revision Required and any custom working status
}
