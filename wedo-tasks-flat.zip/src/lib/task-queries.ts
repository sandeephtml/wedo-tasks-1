import "server-only";
import type { Prisma } from "@prisma/client";
import { prisma } from "./db";
import type { CurrentUser } from "./auth";
import { visibleTasksWhere } from "./task-access";
import { addDays, todayDate } from "./dates";

export type TaskFilters = {
  q?: string;
  client?: string;
  department?: string;
  priority?: string;
  assignee?: string; // user id or "me"
  due?: "overdue" | "today" | "week" | "next7" | "none";
  status?: string;
  completed?: boolean; // include completed tasks
  mine?: boolean; // assigned to me or collaborating
};

export function parseFilters(sp: Record<string, string | string[] | undefined>): TaskFilters {
  const g = (k: string) => (typeof sp[k] === "string" && sp[k] ? (sp[k] as string) : undefined);
  const due = g("due");
  return {
    q: g("q")?.slice(0, 100),
    client: g("client"),
    department: g("department"),
    priority: g("priority"),
    assignee: g("assignee"),
    status: g("status"),
    due: due && ["overdue", "today", "week", "next7", "none"].includes(due) ? (due as TaskFilters["due"]) : undefined,
    completed: g("completed") === "1",
  };
}

export function buildTaskWhere(user: CurrentUser, f: TaskFilters): Prisma.TaskWhereInput {
  const and: Prisma.TaskWhereInput[] = [visibleTasksWhere(user)];
  const today = todayDate();
  if (f.q) {
    const n = Number(f.q.replace(/^#|^WD-/i, ""));
    and.push({
      OR: [
        { title: { contains: f.q, mode: "insensitive" } },
        { description: { contains: f.q, mode: "insensitive" } },
        ...(Number.isInteger(n) && n > 0 ? [{ number: n }] : []),
      ],
    });
  }
  if (f.client) and.push(f.client === "none" ? { clientId: null } : { clientId: f.client });
  if (f.department) and.push({ departmentId: f.department });
  if (f.priority) and.push({ priorityId: f.priority });
  if (f.status) and.push({ statusId: f.status });
  if (f.assignee) {
    const id = f.assignee === "me" ? user.id : f.assignee;
    and.push(f.assignee === "none" ? { assignees: { none: {} } } : { assignees: { some: { userId: id } } });
  }
  if (f.mine) {
    and.push({ OR: [{ assignees: { some: { userId: user.id } } }, { collaborators: { some: { userId: user.id } } }] });
  }
  if (f.due === "overdue") and.push({ dueDate: { lt: today }, status: { category: { not: "DONE" } } });
  if (f.due === "today") and.push({ dueDate: today });
  if (f.due === "week" || f.due === "next7") and.push({ dueDate: { gte: today, lte: addDays(today, 7) } });
  if (f.due === "none") and.push({ dueDate: null });
  if (!f.completed && !f.status) and.push({ status: { category: { not: "DONE" } } });
  return { AND: and };
}

export const taskRowSelect = {
  id: true, number: true, title: true, dueDate: true, startDate: true, statusId: true, priorityId: true,
  clientId: true, departmentId: true, position: true, createdById: true, completedAt: true, updatedAt: true,
  assignees: { select: { userId: true } },
  collaborators: { select: { userId: true } },
  checklist: { select: { done: true } },
  _count: { select: { comments: true } },
} satisfies Prisma.TaskSelect;

type RawRow = Prisma.TaskGetPayload<{ select: typeof taskRowSelect }>;

export type TaskRow = {
  id: string; number: number; title: string; dueDate: string | null; startDate: string | null;
  statusId: string; priorityId: string; clientId: string | null; departmentId: string | null;
  position: number; createdById: string; assigneeIds: string[]; collaboratorIds: string[];
  checklistDone: number; checklistTotal: number; commentCount: number;
};

export function toRow(t: RawRow): TaskRow {
  return {
    id: t.id, number: t.number, title: t.title,
    dueDate: t.dueDate?.toISOString() ?? null, startDate: t.startDate?.toISOString() ?? null,
    statusId: t.statusId, priorityId: t.priorityId, clientId: t.clientId, departmentId: t.departmentId,
    position: t.position, createdById: t.createdById,
    assigneeIds: t.assignees.map((a) => a.userId), collaboratorIds: t.collaborators.map((c) => c.userId),
    checklistDone: t.checklist.filter((c) => c.done).length, checklistTotal: t.checklist.length,
    commentCount: t._count.comments,
  };
}

export async function listTasks(user: CurrentUser, f: TaskFilters, take = 500) {
  const rows = await prisma.task.findMany({
    where: buildTaskWhere(user, f),
    select: taskRowSelect,
    orderBy: [{ position: "asc" }, { dueDate: { sort: "asc", nulls: "last" } }, { createdAt: "desc" }],
    take,
  });
  return rows.map(toRow);
}
