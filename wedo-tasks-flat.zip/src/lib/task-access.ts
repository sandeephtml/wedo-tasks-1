import "server-only";
import type { Prisma } from "@prisma/client";
import { can, type CurrentUser } from "./auth";

/** Prisma filter for tasks the user may see. Founders see all; others see own + department tasks. */
export function visibleTasksWhere(user: CurrentUser): Prisma.TaskWhereInput {
  if (can(user, "task.view_all")) return {};
  const or: Prisma.TaskWhereInput[] = [
    { assignees: { some: { userId: user.id } } },
    { collaborators: { some: { userId: user.id } } },
    { createdById: user.id },
  ];
  if (user.departmentIds.length) or.push({ departmentId: { in: user.departmentIds } });
  return { OR: or };
}

/** Clients the user may see: founders/managers-of-clients see all; others only clients with visible tasks. */
export function visibleClientsWhere(user: CurrentUser): Prisma.ClientWhereInput {
  if (can(user, "task.view_all") || can(user, "client.manage")) return {};
  return { tasks: { some: visibleTasksWhere(user) } };
}

export type TaskInvolvement = {
  createdById: string;
  assignees: { userId: string }[];
  collaborators: { userId: string }[];
};

export function isInvolved(user: CurrentUser, task: TaskInvolvement) {
  return (
    task.createdById === user.id ||
    task.assignees.some((a) => a.userId === user.id) ||
    task.collaborators.some((c) => c.userId === user.id)
  );
}

/** Title, description, dates, priority, client etc. */
export function canEditTaskDetails(user: CurrentUser, task: TaskInvolvement) {
  return can(user, "task.edit_any") || task.createdById === user.id;
}

/** Checklist, links, comments: anyone involved or with edit rights. */
export function canWorkOnTask(user: CurrentUser, task: TaskInvolvement) {
  return can(user, "task.edit_any") || isInvolved(user, task);
}
