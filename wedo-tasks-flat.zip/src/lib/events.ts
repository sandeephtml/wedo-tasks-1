import "server-only";
import type { NotificationType, Prisma, PrismaClient } from "@prisma/client";
import { prisma } from "./db";

type Tx = Prisma.TransactionClient | PrismaClient;

export async function logActivity(
  data: { type: string; message: string; actorId?: string | null; taskId?: string | null; clientId?: string | null },
  tx: Tx = prisma,
) {
  await tx.activity.create({ data });
}

export async function audit(
  actorId: string,
  action: string,
  entityType: string,
  entityId: string | null,
  details?: Prisma.InputJsonValue,
  tx: Tx = prisma,
) {
  await tx.auditLog.create({ data: { actorId, action, entityType, entityId, details } });
}

/** Sends a notification to each recipient except the actor. */
export async function notify(
  recipientIds: Iterable<string>,
  n: { type: NotificationType; title: string; body?: string | null; taskId?: string | null; actorId?: string | null },
  tx: Tx = prisma,
) {
  const ids = [...new Set(recipientIds)].filter((id) => id && id !== n.actorId);
  if (!ids.length) return;
  await tx.notification.createMany({
    data: ids.map((userId) => ({ userId, type: n.type, title: n.title, body: n.body ?? null, taskId: n.taskId ?? null, actorId: n.actorId ?? null })),
  });
}

/** Users who can approve work for a department: founders (view_all + approve) and that department's approvers. */
export async function findApprovers(departmentId: string | null, tx: Tx = prisma) {
  const users = await tx.user.findMany({
    where: {
      isActive: true,
      role: { permissions: { some: { permission: { key: "task.approve" } } } },
    },
    select: {
      id: true,
      departments: { select: { departmentId: true } },
      role: { select: { permissions: { select: { permission: { select: { key: true } } } } } },
    },
  });
  return users
    .filter((u) => {
      const viewAll = u.role.permissions.some((p) => p.permission.key === "task.view_all");
      return viewAll || (departmentId && u.departments.some((d) => d.departmentId === departmentId));
    })
    .map((u) => u.id);
}
