import "server-only";
import { cache } from "react";
import { prisma } from "./db";

/** Reference data used across the app (dropdowns, badges). */
export const getLookups = cache(async () => {
  const [statuses, priorities, departments, clients, users] = await Promise.all([
    prisma.taskStatus.findMany({ orderBy: { order: "asc" } }),
    prisma.priority.findMany({ orderBy: { order: "asc" } }),
    prisma.department.findMany({ orderBy: { name: "asc" }, select: { id: true, name: true, color: true } }),
    prisma.client.findMany({ orderBy: { name: "asc" }, select: { id: true, name: true, status: true } }),
    prisma.user.findMany({
      where: { isActive: true },
      orderBy: { name: "asc" },
      select: { id: true, name: true, title: true, departments: { select: { departmentId: true } } },
    }),
  ]);
  return {
    statuses: statuses.map((s) => ({ id: s.id, key: s.key, name: s.name, color: s.color, category: s.category, isDefault: s.isDefault })),
    priorities: priorities.map((p) => ({ id: p.id, key: p.key, name: p.name, color: p.color, order: p.order, isDefault: p.isDefault })),
    departments,
    clients,
    users: users.map((u) => ({ id: u.id, name: u.name, title: u.title, departmentIds: u.departments.map((d) => d.departmentId) })),
  };
});

export type Lookups = Awaited<ReturnType<typeof getLookups>>;
