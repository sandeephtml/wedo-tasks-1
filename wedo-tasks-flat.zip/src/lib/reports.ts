import "server-only";
import type { Prisma } from "@prisma/client";
import { prisma } from "./db";
import type { CurrentUser } from "./auth";
import { visibleTasksWhere } from "./task-access";
import { dateFromStr, todayDate } from "./dates";
import { bucketOf } from "./status-buckets";

export type ReportFilters = { from?: string; to?: string; client?: string; department?: string; basis: "due" | "created" | "completed" };

export function parseReportFilters(sp: Record<string, string | string[] | undefined>): ReportFilters {
  const g = (k: string) => (typeof sp[k] === "string" && sp[k] ? (sp[k] as string) : undefined);
  const date = (v?: string) => (v && /^\d{4}-\d{2}-\d{2}$/.test(v) ? v : undefined);
  const basis = g("basis");
  return { from: date(g("from")), to: date(g("to")), client: g("client"), department: g("department"), basis: basis === "created" || basis === "completed" ? basis : "due" };
}

export function reportWhere(user: CurrentUser, f: ReportFilters): Prisma.TaskWhereInput {
  const and: Prisma.TaskWhereInput[] = [visibleTasksWhere(user)];
  if (f.client) and.push({ clientId: f.client === "none" ? null : f.client });
  if (f.department) and.push({ departmentId: f.department });
  const field = f.basis === "created" ? "createdAt" : f.basis === "completed" ? "completedAt" : "dueDate";
  const range: Prisma.DateTimeFilter = {};
  if (f.from) range.gte = dateFromStr(f.from);
  if (f.to) range.lt = new Date(dateFromStr(f.to).getTime() + 86_400_000);
  if (f.from || f.to) and.push({ [field]: range });
  return { AND: and };
}

export async function getReportTasks(user: CurrentUser, f: ReportFilters) {
  return prisma.task.findMany({
    where: reportWhere(user, f),
    orderBy: [{ dueDate: { sort: "asc", nulls: "last" } }, { number: "asc" }],
    include: {
      status: true, priority: true, client: { select: { name: true } }, department: { select: { name: true } },
      createdBy: { select: { name: true } }, assignees: { include: { user: { select: { id: true, name: true } } } },
      checklist: { select: { done: true } },
    },
    take: 10000,
  });
}

type ReportTask = Awaited<ReturnType<typeof getReportTasks>>[number];

export function summarize(tasks: ReportTask[]) {
  const today = todayDate();
  type Row = { key: string; label: string; total: number; open: number; done: number; overdue: number; hours: number };
  const groups = { client: new Map<string, Row>(), department: new Map<string, Row>(), member: new Map<string, Row>() };
  const add = (m: Map<string, Row>, key: string, label: string, t: ReportTask) => {
    const r = m.get(key) ?? { key, label, total: 0, open: 0, done: 0, overdue: 0, hours: 0 };
    const done = bucketOf(t.status) === "done";
    r.total++; if (done) r.done++; else r.open++;
    if (!done && t.dueDate && t.dueDate < today) r.overdue++;
    r.hours += t.estimateHours ?? 0;
    m.set(key, r);
  };
  for (const t of tasks) {
    add(groups.client, t.clientId ?? "none", t.client?.name ?? "Internal", t);
    add(groups.department, t.departmentId ?? "none", t.department?.name ?? "No department", t);
    if (!t.assignees.length) add(groups.member, "none", "Unassigned", t);
    for (const a of t.assignees) add(groups.member, a.user.id, a.user.name, t);
  }
  const sort = (m: Map<string, Row>) => [...m.values()].sort((a, b) => b.total - a.total || a.label.localeCompare(b.label));
  return { byClient: sort(groups.client), byDepartment: sort(groups.department), byMember: sort(groups.member) };
}

/** RFC 4180 CSV cell, with spreadsheet formula-injection protection. */
export function csvCell(v: unknown) {
  let s = v === null || v === undefined ? "" : String(v);
  if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`;
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

export function tasksToCsv(tasks: ReportTask[]) {
  const today = todayDate();
  const d = (x: Date | null) => (x ? x.toISOString().slice(0, 10) : "");
  const header = ["Task #", "Title", "Client", "Department", "Status", "Priority", "Assignees", "Created by", "Start date", "Due date", "Completed", "Overdue", "Estimate (h)", "Checklist", "Created at"];
  const rows = tasks.map((t) => {
    const done = t.status.category === "DONE";
    return [
      t.number, t.title, t.client?.name ?? "Internal", t.department?.name ?? "", t.status.name, t.priority.name,
      t.assignees.map((a) => a.user.name).join("; "), t.createdBy.name, d(t.startDate), d(t.dueDate),
      t.completedAt ? t.completedAt.toISOString().slice(0, 10) : "", !done && t.dueDate && t.dueDate < today ? "Yes" : "No",
      t.estimateHours ?? "", t.checklist.length ? `${t.checklist.filter((c) => c.done).length}/${t.checklist.length}` : "", t.createdAt.toISOString(),
    ];
  });
  return "﻿" + [header, ...rows].map((r) => r.map(csvCell).join(",")).join("\r\n");
}
