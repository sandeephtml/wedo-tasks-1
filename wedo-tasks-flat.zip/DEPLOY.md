# Deploy WeDo Tasks: Vercel or Netlify

Same code for both. On every deploy the build creates/updates the database tables and the starting
data automatically (it never overwrites existing passwords), then builds the app.

## Environment variables (identical on both)

| Name | Value |
| --- | --- |
| `DATABASE_URL` | Neon string, pooling **ON**, without `&channel_binding=require`, plus `&pgbouncer=true&connect_timeout=15` |
| `DIRECT_URL` | Neon string, pooling **OFF**, without `&channel_binding=require` |
| `AUTH_SECRET` | random 64 characters (`openssl rand -hex 32`) |
| `CRON_SECRET` | random string (`openssl rand -hex 24`) |
| `APP_TIMEZONE` | `Asia/Kolkata` |
| `SEED_SUPER_ADMIN_EMAIL` | `sandeep@wedomarketing.io` |
| `SEED_SUPER_ADMIN_PASSWORD` | 10+ characters, with a letter and a number |
| `SEED_ADMIN_EMAIL` | `pradeep@wedomarketing.io` |
| `SEED_ADMIN_PASSWORD` | 10+ characters, with a letter and a number |
| `SEED_EMAIL_DOMAIN` | `wedomarketing.io` |

Do **not** set `NODE_ENV` yourself.
Optional, one deploy only: `SEED_RESET_FOUNDER_PASSWORDS=true` resets Sandeep/Pradeep to the
passwords above (for existing accounts). Remove it afterwards.

## Vercel
1. vercel.com → **Add New → Project** → import the repo (or from your computer: `npm i -g vercel`, then `vercel` inside the folder).
2. Framework: Next.js (auto). Leave build settings on default: Vercel runs the `vercel-build` script.
3. Add the environment variables above, then **Deploy**.
4. The daily job (recurring tasks + overdue alerts) is configured in `vercel.json` and runs automatically.
5. Domain: Project → Settings → Domains → add `task.wedomarketing.io`, then add the CNAME record it shows at your DNS provider (Hostinger: Domains → DNS / Nameservers).

## Netlify
1. app.netlify.com → **Add new site** → import the repo (or from your computer: `npm i -g netlify-cli`, then `netlify deploy --build --prod` inside the folder).
   Note: dragging a folder onto Netlify does not run a build, so use import or the CLI.
2. `netlify.toml` already sets the build, Node 20 and the Next.js runtime. Leave the build settings alone.
3. Add the environment variables above (Site configuration → Environment variables; scopes must include **Builds**), then deploy.
4. The daily job runs from `netlify/functions/daily-cron.mts`.
5. Domain: Domain management → Add a domain → `task.wedomarketing.io`, then add the CNAME record it shows.

## After deploying
- Open `/api/health`: `"ok": true` means everything is set up. Otherwise it names the setting to fix.
- Log in at `/login` as Sandeep with `SEED_SUPER_ADMIN_PASSWORD`.
- Team members' temporary passwords are printed once in the first deploy log under **NEW LOGINS — SHOWN ONCE**. You can also reset any of them from the Team page.
