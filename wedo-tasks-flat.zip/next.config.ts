import type { NextConfig } from "next";

// Serverless-friendly: no `output: "standalone"`, no local file storage.
const nextConfig: NextConfig = {
  poweredByHeader: false,
  // Lint runs separately (`npm run lint`); never block a deploy on lint tooling.
  eslint: { ignoreDuringBuilds: true },
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          { key: "X-Frame-Options", value: "DENY" },
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=()" },
        ],
      },
    ];
  },
};

export default nextConfig;
