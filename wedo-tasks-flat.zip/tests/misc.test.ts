import { describe, expect, it } from "vitest";
import { findMentionedUserIds } from "@/lib/mentions";
import { csvCell } from "@/lib/reports";
import { isOverdue, plural, todayStr, dateFromStr } from "@/lib/dates";
import { bucketOf } from "@/lib/status-buckets";
import { signSession, verifySession } from "@/lib/session";
import { passwordSchema, taskInputSchema } from "@/lib/validation";

const users = [{ id: "1", name: "Neha" }, { id: "2", name: "Dhiraj" }, { id: "3", name: "Test Manager" }];

describe("mentions", () => {
  it("matches first names case-insensitively and ignores emails", () => {
    expect(findMentionedUserIds("Hey @neha and @Dhiraj, please check", users).sort()).toEqual(["1", "2"]);
    expect(findMentionedUserIds("mail neha@wedomarketing.io", users)).toEqual([]);
    expect(findMentionedUserIds("@TestManager @Test.", users)).toEqual(["3"]);
  });
});

describe("csv", () => {
  it("quotes and neutralises formulas", () => {
    expect(csvCell('a,"b"')).toBe('"a,""b"""');
    expect(csvCell("=HYPERLINK(1)")).toBe("'=HYPERLINK(1)");
    expect(csvCell(null)).toBe("");
  });
});

describe("dates", () => {
  it("computes today in the agency timezone", () => {
    // 20:00 UTC on 31 Oct is already 1 Nov in India
    expect(todayStr("Asia/Kolkata", new Date("2026-10-31T20:00:00Z"))).toBe("2026-11-01");
  });
  it("flags overdue only for open tasks with past due dates", () => {
    const today = dateFromStr("2026-10-31");
    expect(isOverdue("2026-10-30T00:00:00Z", false, today)).toBe(true);
    expect(isOverdue("2026-10-31T00:00:00Z", false, today)).toBe(false);
    expect(isOverdue("2026-10-30T00:00:00Z", true, today)).toBe(false);
    expect(isOverdue(null, false, today)).toBe(false);
  });
  it("pluralises", () => {
    expect(plural(1, "task")).toBe("1 task");
    expect(plural(3, "task")).toBe("3 tasks");
  });
});

describe("status buckets", () => {
  it("maps statuses to report buckets", () => {
    expect(bucketOf({ key: "PENDING", category: "OPEN" })).toBe("pending");
    expect(bucketOf({ key: "UNDER_REVIEW", category: "REVIEW" })).toBe("in_progress");
    expect(bucketOf({ key: "ON_HOLD", category: "OPEN" })).toBe("on_hold");
    expect(bucketOf({ key: "X", category: "DONE" })).toBe("done");
  });
});

describe("session tokens", () => {
  it("round-trips and rejects tampering", async () => {
    process.env.AUTH_SECRET = "x".repeat(40);
    const t = await signSession({ sub: "u1", sv: 3 });
    expect(await verifySession(t)).toEqual({ sub: "u1", sv: 3 });
    expect(await verifySession(t.slice(0, -2) + "aa")).toBeNull();
    process.env.AUTH_SECRET = "y".repeat(40);
    expect(await verifySession(t)).toBeNull();
  });
});

describe("validation", () => {
  it("enforces password policy", () => {
    expect(passwordSchema.safeParse("short1").success).toBe(false);
    expect(passwordSchema.safeParse("onlyletterslong").success).toBe(false);
    expect(passwordSchema.safeParse("goodPassword1").success).toBe(true);
  });
  it("normalises task input", () => {
    const r = taskInputSchema.parse({ title: " Report ", priorityId: "p", clientId: "", dueDate: "", estimateHours: "", links: [{ url: "drive.google.com/x" }] });
    expect(r.title).toBe("Report");
    expect(r.clientId).toBeNull();
    expect(r.links[0]!.url).toBe("https://drive.google.com/x");
    expect(taskInputSchema.safeParse({ title: "a", priorityId: "p", startDate: "2026-11-05", dueDate: "2026-11-01" }).success).toBe(false);
  });
});
