# Deploying WeDo Tasks on Hostinger

The app runs as a **Node.js web app** on Hostinger and the database stays on **Neon** (Hostinger's
hosting databases are MySQL; this app needs PostgreSQL).

> You need a Hostinger plan with Node.js web apps (Business / Cloud web hosting, or a VPS).
> Menu names in hPanel may differ slightly from what's written here.

## 1. Set up the database (once)
Do this on your own computer (needs Node.js 20+ from https://nodejs.org), inside the unzipped folder:

```bash
npm install
```
```bash
export DATABASE_URL="<pooled Neon string>" DIRECT_URL="<direct Neon string>"
```
```bash
npx prisma migrate deploy
```
```bash
SEED_SUPER_ADMIN_PASSWORD="<strong password 1>" SEED_ADMIN_PASSWORD="<strong password 2>" npm run db:seed
```
Copy the team passwords it prints. They are shown only once.
(On Windows PowerShell, set variables with `$env:DATABASE_URL="..."` instead of `export`.)

Neon strings:
- `DATABASE_URL`: pooling ON, remove `&channel_binding=require`, add `&pgbouncer=true&connect_timeout=15`
- `DIRECT_URL`: pooling OFF, remove `&channel_binding=require`

## 2. Create the Node.js app in hPanel
1. hPanel → **Websites** → **Add website** → **Node.js Apps** (or **Deploy Node.js app**).
2. Choose **Upload files** and upload the project zip (WITHOUT `node_modules` or `.next`).
3. Framework: **Next.js**. Node version: **20** or **22**.
   - Build command: `npm run build`
   - Start command: `npm start`
   - Install command: `npm install`
4. Under **Environment variables** add:

| Name | Value |
| --- | --- |
| `DATABASE_URL` | pooled Neon string |
| `DIRECT_URL` | direct Neon string |
| `AUTH_SECRET` | random 64+ characters (e.g. `openssl rand -hex 32`) |
| `CRON_SECRET` | another random string |
| `APP_TIMEZONE` | `Asia/Kolkata` |
| `NODE_ENV` | `production` |

5. Deploy. Open the temporary URL Hostinger gives you and sign in as Sandeep.

## 3. Connect your domain
In the app's dashboard → **Domains** → connect e.g. `tasks.wedomarketing.io`.
- If wedomarketing.io's DNS is at Hostinger, it's set up automatically.
- If it's elsewhere, add the DNS record Hostinger shows (an A record or CNAME for `tasks`).
Then make sure **SSL** is on (hPanel → Security → SSL). The app needs HTTPS: its login cookie is
marked Secure in production.

## 4. Daily job (recurring tasks + overdue alerts)
`vercel.json` and `netlify/` are ignored on Hostinger. Instead, create a cron job:
hPanel → **Advanced** → **Cron Jobs** → custom command, once a day:

```bash
curl -s -H "Authorization: Bearer YOUR_CRON_SECRET" https://tasks.wedomarketing.io/api/cron/daily
```

Suggested time: 06:00 IST (00:30 if the server clock is UTC). Running it twice does no harm.

## 5. Updating later
Upload the new code, redeploy, and if `prisma/migrations` changed run `npx prisma migrate deploy` again
from your computer (step 1 with the same env vars).
