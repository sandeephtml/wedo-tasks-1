import type { Config } from "tailwindcss";

// All brand colours and fonts come from CSS variables in src/app/theme.css.
// To re-theme, edit that one file — nothing here needs to change.
const v = (name: string) => `rgb(var(--${name}) / <alpha-value>)`;

export default {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: { DEFAULT: v("brand"), hover: v("brand-hover"), soft: v("brand-soft"), fg: v("brand-fg") },
        accent: { DEFAULT: v("accent"), soft: v("accent-soft") },
        sidebar: { DEFAULT: v("sidebar"), hover: v("sidebar-hover"), active: v("sidebar-active"), fg: v("sidebar-fg"), muted: v("sidebar-muted") },
        page: v("page"),
        surface: v("surface"),
        line: v("line"),
        ink: { DEFAULT: v("ink"), muted: v("ink-muted"), faint: v("ink-faint") },
        danger: { DEFAULT: v("danger"), soft: v("danger-soft") },
        success: { DEFAULT: v("success"), soft: v("success-soft") },
        warning: { DEFAULT: v("warning"), soft: v("warning-soft") },
      },
      fontFamily: {
        sans: ["var(--font-sans)"],
        display: ["var(--font-display)"],
      },
      borderRadius: { card: "var(--radius-card)" },
      boxShadow: { card: "var(--shadow-card)", pop: "var(--shadow-pop)" },
    },
  },
  plugins: [],
} satisfies Config;
